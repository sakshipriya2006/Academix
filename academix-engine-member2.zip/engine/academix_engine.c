/* academix_engine.c — Member 2's engine adapted to Academix. See academix_engine.h */
#include <stdio.h>
#include <string.h>
#include "academix_engine.h"
#include "models.h"
#include "grading.h"
#include "risk.h"
#include "platform.h"

const int AX_CREDITS[AX_SUBJECTS] = { 4, 4, 3, 3, 2 };

static const char *status_for(RiskLevel level)
{
    switch (level) {
    case RISK_GREEN:  return "SAFE";
    case RISK_YELLOW: return "MODERATE";
    default:          return "HIGH RISK";
    }
}

const char *ax_validate(const AxInput *in)
{
    int i;
    if (!in) return "No input";
    if (in->attendance < 0.0f || in->attendance > 100.0f)
        return "Attendance must be between 0 and 100";
    for (i = 0; i < AX_CIE_TESTS; i++)
        if (in->cie[i] < 0.0f || in->cie[i] > AX_CIE_MAX)
            return "Each CIE mark must be between 0 and 30";
    for (i = 0; i < AX_SUBJECTS; i++)
        if (in->marks[i] < 0.0f || in->marks[i] > AX_MARK_MAX)
            return "Each subject mark must be between 0 and 100";
    return NULL;
}

int ax_compute(const AxInput *in, AxResult *out)
{
    StudentRecord rec;
    AcademicResult res;
    RiskReport risk;
    TrendSeries cie_trend;
    int i;

    if (!out || ax_validate(in) != NULL) return -1;
    memset(out, 0, sizeof(*out));
    memset(&rec, 0, sizeof rec);

    /* Step 1: build a record the core engine understands */
    rec.subject_count = AX_SUBJECTS;
    for (i = 0; i < AX_SUBJECTS; i++) {
        snprintf(rec.subjects[i].subject_code, MAX_CODE_LEN, "SUB%d", i + 1);
        rec.subjects[i].marks_obtained = in->marks[i];
        rec.subjects[i].max_marks      = AX_MARK_MAX;
        rec.subjects[i].pass_marks     = 40.0f;
        rec.subjects[i].credits        = AX_CREDITS[i];
    }
    /* attendance given as a %, stored as "attended out of 1000" (0.1 % precision) */
    rec.attendance.classes_held     = 1000;
    rec.attendance.classes_attended = (int)(in->attendance * 10.0f + 0.5f);

    /* Step 2: grades, SGPA, pass/fail */
    if (grading_compute(&rec, &res) != 0) return -1;

    /* Step 3: CIE 1 -> 2 -> 3 is the "grade trajectory" for the risk matrix */
    cie_trend.count = AX_CIE_TESTS;
    for (i = 0; i < AX_CIE_TESTS; i++) {
        cie_trend.values[i] = in->cie[i] / AX_CIE_MAX * 100.0f;
        out->cie_avg += in->cie[i];
    }
    out->cie_avg /= (float)AX_CIE_TESTS;

    /* Step 4: At-Risk Matrix */
    if (risk_evaluate(&rec, &res, NULL, &cie_trend, &risk) != 0) return -1;

    /* Step 5: copy results out */
    out->sgpa            = res.sgpa;
    out->percentage      = res.percentage;
    out->failed_subjects = res.failed_subjects;
    for (i = 0; i < AX_SUBJECTS; i++)
        snprintf(out->grades[i], sizeof out->grades[i], "%s", res.subjects[i].grade);
    out->cie_slope   = risk.marks_slope;
    out->risk_score  = risk.score;
    snprintf(out->status, sizeof out->status, "%s", status_for(risk.level));
    out->reason_count = risk.reason_count;
    for (i = 0; i < risk.reason_count && i < AX_MAX_REASONS; i++)
        snprintf(out->reasons[i], AX_REASON_LEN, "%s", risk.reasons[i]);
    return 0;
}

double ax_benchmark(int n)
{
    AxInput in;
    AxResult out;
    volatile float sink = 0.0f;
    double t0;
    int i, j;

    if (n <= 0) n = 10000;
    t0 = platform_now_seconds();
    for (i = 0; i < n; i++) {
        in.attendance = (float)(50 + (i * 7) % 51);
        for (j = 0; j < AX_CIE_TESTS; j++) in.cie[j] = (float)((i * 3 + j * 5) % 31);
        for (j = 0; j < AX_SUBJECTS; j++) in.marks[j] = (float)((i * 11 + j * 13) % 101);
        ax_compute(&in, &out);
        sink += out.sgpa;
    }
    (void)sink;
    return (platform_now_seconds() - t0) * 1000.0;
}
