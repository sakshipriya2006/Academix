/*
 * grading.h — Automated Processing Engine (Member 2, core academic task).
 * Calculates: total marks, percentage, letter grade, grade point, SGPA,
 * subject-wise pass/fail, attendance shortage and final PASS/FAIL.
 *
 * Grade scale (MAKAUT-style 10-point; change the table in grading.c if
 * your professor uses a different one):
 *   O  >= 90  (10) | E >= 80 (9) | A >= 70 (8) | B >= 60 (7)
 *   C  >= 50  (6)  | D >= 40 (5) | F  < 40 (0)
 */
#ifndef GRADING_H
#define GRADING_H

#include "models.h"

#define PASS_PERCENT              40.0f  /* overall % needed to pass        */
#define ATTENDANCE_REQUIRED       75.0f  /* below this => shortage flag     */
#define FAIL_ON_ATTENDANCE_SHORTAGE 0    /* set 1 if shortage = FAIL        */

typedef struct {
    float       min_percent;
    const char *letter;
    float       point;
} GradeBand;

/* Percentage, safe against divide-by-zero. Returns 0..100. */
float grading_percent(float obtained, float max);

/* Grade band for a percentage. Never returns NULL. */
const GradeBand *grading_band(float percent);

/* Index (0..GRADE_BAND_COUNT-1) of a band; used for class histograms. */
int grading_band_index(float percent);

/* Letter for index i (for printing the histogram). */
const char *grading_band_letter(int index);

/* Main function: fills *out from *rec.  Returns 0 on success,
 * -1 if the input is invalid (NULL pointer / bad numbers). */
int grading_compute(const StudentRecord *rec, AcademicResult *out);

/* Class-wise summary over n results. names[i] may be NULL.
 * risks may be NULL (then risk_count stays 0). */
void grading_class_summary(const AcademicResult *results,
                           const char (*names)[MAX_NAME_LEN],
                           const RiskLevel *risks,
                           int n, ClassSummary *out);

#endif /* GRADING_H */
