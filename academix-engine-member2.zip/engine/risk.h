/*
 * risk.h — Pure-C Predictive "At-Risk" Matrix (Member 2, unique feature).
 *
 * HOW IT WORKS (simple words):
 *  1. We look at 5 warning signs ("features"), each turned into a number
 *     between 0 (no problem) and 1 (big problem):
 *       f1  attendance is low            (below 75 %)
 *       f2  attendance is FALLING        (slope of last weeks, by regression)
 *       f3  marks are low                (below 60 %)
 *       f4  marks are FALLING            (slope of last tests, by regression)
 *       f5  subjects already failed
 *  2. Weighted score:  score = 100 * (w1*f1 + w2*f2 + w3*f3 + w4*f4 + w5*f5)
 *       score <  30  -> GREEN,  30..60 -> YELLOW,  >= 60 -> RED
 *  3. A 3x3 Risk Matrix (attendance band x marks band) gives a second colour.
 *  4. Final colour = the WORSE of the two  (safe side).
 */
#ifndef RISK_H
#define RISK_H

#include "models.h"

#define RISK_FEATURES 5

/* Least-squares slope of a series (change per period). 0 if < 2 points. */
float risk_slope(const TrendSeries *s);

/* Evaluate one student.
 *  rec     : profile + marks + attendance (required)
 *  result  : output of grading_compute for the same student (required)
 *  att     : attendance % history, oldest first (may be NULL / empty)
 *  marks   : test % history, oldest first (may be NULL / empty)
 * Returns 0 on success, -1 on bad input. */
int risk_evaluate(const StudentRecord *rec, const AcademicResult *result,
                  const TrendSeries *att, const TrendSeries *marks,
                  RiskReport *out);

const char *risk_level_name(RiskLevel level);   /* "GREEN" ...           */
const char *risk_level_hex(RiskLevel level);    /* "#22c55e" ... for UI  */

#endif /* RISK_H */
