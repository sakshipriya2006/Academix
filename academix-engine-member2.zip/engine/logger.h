/*
 * logger.h — source of the "Terminal Mirror" live log stream (Member 2).
 *
 * Every log line looks exactly like the brief asks:
 *     [DATABASE 19:12:45] SUCCESS: Student ID 202601 updated
 *
 * Each line is:
 *   1. printed to stdout (the real C terminal),
 *   2. stored in a ring buffer of the last LOG_RING_SIZE lines
 *      (for page refresh / polling),
 *   3. sent to a "listener" callback — Member 4 registers one that pushes
 *      the line to the browser through Server-Sent Events / WebSockets.
 */
#ifndef LOGGER_H
#define LOGGER_H

#define LOG_LINE_LEN  192
#define LOG_RING_SIZE 256

typedef enum {
    LOG_CAT_DATABASE, LOG_CAT_ENGINE, LOG_CAT_RISK,
    LOG_CAT_TELEMETRY, LOG_CAT_BENCHMARK, LOG_CAT_SERVER
} LogCategory;

typedef enum { LOG_INFO, LOG_SUCCESS, LOG_WARN, LOG_ERROR } LogLevel;

/* Member 4's hook. Called once per line, from the thread that logged it.
 * 'seq' increases by 1 for every line (use it as the SSE "id:"). */
typedef void (*LogListener)(const char *line, unsigned long seq, void *user);

void logger_init(void);
void logger_shutdown(void);
void logger_set_listener(LogListener fn, void *user);
void logger_set_stdout(int enabled);            /* 1 = print (default) */

/* printf-style. Returns the sequence number of the line. */
unsigned long log_event(LogCategory cat, LogLevel level, const char *fmt, ...)
#if defined(__GNUC__)
    __attribute__((format(printf, 3, 4)))
#endif
    ;

/* Copy lines with seq > after_seq (oldest first). Returns how many. */
int logger_copy_since(unsigned long after_seq, char lines[][LOG_LINE_LEN],
                      unsigned long *seqs, int max);

unsigned long logger_latest_seq(void);

#endif /* LOGGER_H */
