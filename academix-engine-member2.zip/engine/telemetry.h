/*
 * telemetry.h — "Under the Hood" C-Telemetry (Member 2, unique feature).
 * Samples live RAM (KB), CPU time, CPU %, uptime and DB activity using
 * real system calls:
 *   Linux  : /proc/self/status, getrusage(), sysinfo()
 *   Windows: GetProcessMemoryInfo(), GetProcessTimes(), GlobalMemoryStatusEx()
 *   macOS  : task_info(), getrusage(), sysctl()
 * All functions are thread-safe (CivetWeb runs many threads).
 */
#ifndef TELEMETRY_H
#define TELEMETRY_H

typedef struct {
    long          ram_kb;               /* current memory used by THIS process */
    long          peak_ram_kb;          /* highest so far                      */
    long          system_total_kb;      /* whole machine                       */
    long          system_free_kb;
    double        cpu_user_sec;         /* CPU time spent in our code          */
    double        cpu_system_sec;       /* CPU time spent in the OS for us     */
    double        cpu_total_sec;
    double        cpu_usage_percent;    /* since the previous sample           */
    double        uptime_sec;
    int           active_db_connections;
    unsigned long requests_served;
    unsigned long db_operations;
    double        last_op_ms;           /* time of the last engine request     */
    double        avg_op_ms;
} TelemetrySnapshot;

void telemetry_init(void);
void telemetry_shutdown(void);

/* Counters — called by the engine / DB layer / bridge */
void telemetry_db_connection_opened(void);
void telemetry_db_connection_closed(void);
void telemetry_count_request(void);
void telemetry_count_db_ops(unsigned long n);
void telemetry_record_op_time(double ms);

/* Take a live reading. Returns 0 on success. */
int telemetry_sample(TelemetrySnapshot *out);

#endif /* TELEMETRY_H */
