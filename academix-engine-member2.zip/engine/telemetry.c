/* telemetry.c — live system metrics (Member 2). See telemetry.h. */
#if !defined(_WIN32) && !defined(__APPLE__)
  #define _GNU_SOURCE
#endif
#include <stdio.h>
#include <string.h>
#include "telemetry.h"
#include "platform.h"

#ifdef _WIN32
  #include <psapi.h>              /* link with -lpsapi */
#else
  #include <sys/resource.h>
  #include <unistd.h>
  #ifdef __APPLE__
    #include <mach/mach.h>
    #include <sys/sysctl.h>
  #else
    #include <sys/sysinfo.h>
  #endif
#endif

static eng_mutex_t   g_lock;
static int           g_ready = 0;
static double        g_start_wall = 0.0;
static int           g_db_conn = 0;
static unsigned long g_requests = 0;
static unsigned long g_db_ops = 0;
static double        g_last_ms = 0.0;
static double        g_total_ms = 0.0;
static unsigned long g_timed_ops = 0;
static double        g_prev_wall = 0.0;
static double        g_prev_cpu = 0.0;
static long          g_peak_kb = 0;

void telemetry_init(void)
{
    if (g_ready) return;
    MUTEX_INIT(&g_lock);
    g_start_wall = platform_now_seconds();
    g_prev_wall  = g_start_wall;
    g_ready = 1;
}

void telemetry_shutdown(void)
{
    if (!g_ready) return;
    MUTEX_DESTROY(&g_lock);
    g_ready = 0;
}

#define WITH_LOCK(stmt) do { if (!g_ready) telemetry_init(); \
    MUTEX_LOCK(&g_lock); stmt; MUTEX_UNLOCK(&g_lock); } while (0)

void telemetry_db_connection_opened(void) { WITH_LOCK(g_db_conn++); }
void telemetry_db_connection_closed(void) { WITH_LOCK(if (g_db_conn > 0) g_db_conn--); }
void telemetry_count_request(void)        { WITH_LOCK(g_requests++); }
void telemetry_count_db_ops(unsigned long n) { WITH_LOCK(g_db_ops += n); }
void telemetry_record_op_time(double ms)
{
    WITH_LOCK(g_last_ms = ms; g_total_ms += ms; g_timed_ops++);
}

/* ---------------- platform readers ---------------- */
static void read_process_memory(long *rss_kb, long *peak_kb)
{
    *rss_kb = 0; *peak_kb = 0;
#ifdef _WIN32
    {
        PROCESS_MEMORY_COUNTERS pmc;
        if (GetProcessMemoryInfo(GetCurrentProcess(), &pmc, sizeof pmc)) {
            *rss_kb  = (long)(pmc.WorkingSetSize / 1024);
            *peak_kb = (long)(pmc.PeakWorkingSetSize / 1024);
        }
    }
#elif defined(__APPLE__)
    {
        struct mach_task_basic_info info;
        mach_msg_type_number_t count = MACH_TASK_BASIC_INFO_COUNT;
        struct rusage ru;
        if (task_info(mach_task_self(), MACH_TASK_BASIC_INFO,
                      (task_info_t)&info, &count) == KERN_SUCCESS)
            *rss_kb = (long)(info.resident_size / 1024);
        if (getrusage(RUSAGE_SELF, &ru) == 0)
            *peak_kb = (long)(ru.ru_maxrss / 1024);   /* bytes on macOS */
    }
#else
    {
        FILE *f = fopen("/proc/self/status", "r");
        char line[256];
        if (f) {
            while (fgets(line, sizeof line, f)) {
                if (strncmp(line, "VmRSS:", 6) == 0)  sscanf(line + 6, "%ld", rss_kb);
                else if (strncmp(line, "VmHWM:", 6) == 0) sscanf(line + 6, "%ld", peak_kb);
            }
            fclose(f);
        }
        if (*peak_kb == 0) {
            struct rusage ru;
            if (getrusage(RUSAGE_SELF, &ru) == 0) *peak_kb = ru.ru_maxrss; /* KB on Linux */
        }
    }
#endif
}

static void read_cpu_times(double *user, double *sys)
{
    *user = 0.0; *sys = 0.0;
#ifdef _WIN32
    {
        FILETIME c, e, k, u;
        if (GetProcessTimes(GetCurrentProcess(), &c, &e, &k, &u)) {
            ULARGE_INTEGER ku, uu;
            ku.LowPart = k.dwLowDateTime; ku.HighPart = k.dwHighDateTime;
            uu.LowPart = u.dwLowDateTime; uu.HighPart = u.dwHighDateTime;
            *sys  = (double)ku.QuadPart / 1e7;    /* 100-ns units */
            *user = (double)uu.QuadPart / 1e7;
        }
    }
#else
    {
        struct rusage ru;
        if (getrusage(RUSAGE_SELF, &ru) == 0) {
            *user = (double)ru.ru_utime.tv_sec + (double)ru.ru_utime.tv_usec / 1e6;
            *sys  = (double)ru.ru_stime.tv_sec + (double)ru.ru_stime.tv_usec / 1e6;
        }
    }
#endif
}

static void read_system_memory(long *total_kb, long *free_kb)
{
    *total_kb = 0; *free_kb = 0;
#ifdef _WIN32
    {
        MEMORYSTATUSEX ms;
        ms.dwLength = sizeof ms;
        if (GlobalMemoryStatusEx(&ms)) {
            *total_kb = (long)(ms.ullTotalPhys / 1024);
            *free_kb  = (long)(ms.ullAvailPhys / 1024);
        }
    }
#elif defined(__APPLE__)
    {
        unsigned long long mem = 0; size_t len = sizeof mem;
        if (sysctlbyname("hw.memsize", &mem, &len, NULL, 0) == 0)
            *total_kb = (long)(mem / 1024);
    }
#else
    {
        struct sysinfo si;
        if (sysinfo(&si) == 0) {
            *total_kb = (long)((unsigned long long)si.totalram * si.mem_unit / 1024);
            *free_kb  = (long)((unsigned long long)si.freeram  * si.mem_unit / 1024);
        }
    }
#endif
}

int telemetry_sample(TelemetrySnapshot *out)
{
    double now, cpu, dwall;
    if (!out) return -1;
    if (!g_ready) telemetry_init();
    memset(out, 0, sizeof(*out));

    read_process_memory(&out->ram_kb, &out->peak_ram_kb);
    read_cpu_times(&out->cpu_user_sec, &out->cpu_system_sec);
    read_system_memory(&out->system_total_kb, &out->system_free_kb);
    out->cpu_total_sec = out->cpu_user_sec + out->cpu_system_sec;
    now = platform_now_seconds();

    MUTEX_LOCK(&g_lock);
    if (out->peak_ram_kb < out->ram_kb) out->peak_ram_kb = out->ram_kb;
    if (out->peak_ram_kb > g_peak_kb) g_peak_kb = out->peak_ram_kb;
    out->peak_ram_kb = g_peak_kb;
    out->uptime_sec  = now - g_start_wall;
    dwall = now - g_prev_wall;
    cpu   = out->cpu_total_sec;
    out->cpu_usage_percent = dwall > 0.0 ? 100.0 * (cpu - g_prev_cpu) / dwall : 0.0;
    if (out->cpu_usage_percent < 0.0) out->cpu_usage_percent = 0.0;
    g_prev_wall = now;
    g_prev_cpu  = cpu;
    out->active_db_connections = g_db_conn;
    out->requests_served = g_requests;
    out->db_operations   = g_db_ops;
    out->last_op_ms      = g_last_ms;
    out->avg_op_ms       = g_timed_ops ? g_total_ms / (double)g_timed_ops : 0.0;
    MUTEX_UNLOCK(&g_lock);
    return 0;
}
