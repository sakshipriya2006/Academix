# engine/ — Member 2: Backend C Developer (The Processing Engine)

This folder is **only Member 2's work**. No teammate's file was changed.

## What this engine does
| Feature | Function | Used by page |
|---|---|---|
| SGPA from 5 subjects (credits 4, 4, 3, 3, 2), MAKAUT 10-point scale | `ax_compute()` | Add / Update student (`/api/save`) |
| CIE average (out of 30) | `ax_compute()` | Add / Update student |
| Grade per subject (O E A B C D F) + failed subjects | `ax_compute()` | – (available) |
| Pure-C At-Risk Matrix → `"SAFE"`, `"MODERATE"`, `"HIGH RISK"` | `ax_compute()` | Status pill + summary cards |
| Input checks (attendance 0–100, CIE 0–30, marks 0–100) | `ax_validate()` | Error message on the page |
| 10,000-record benchmark | `ax_benchmark(10000)` | "Run 10,000-Record C Benchmark" (`/api/stress`) |
| Live RAM / CPU telemetry | `telemetry_sample()` | (for a telemetry widget) |
| Terminal log lines `[DATABASE 19:12:45] SUCCESS: …` | `log_event()`, `logger_copy_since()` | (for the terminal box) |

The status words match exactly what `index.html` (CSS classes `SAFE`, `MODERATE`, `HIGH`) and `database.c` (`get_summary_report_json`) already expect.

## How the At-Risk Matrix decides (simple words)
1. It looks at attendance, semester marks, failed subjects, and whether **CIE 1 → CIE 2 → CIE 3 is going down**. That trend is measured with a straight-line fit (linear regression).
2. These warning signs are combined into a score from 0 to 100, using weights.
3. A 3×3 table (attendance band × marks band) gives a second opinion.
4. The worse of the two decides the result: GREEN becomes **SAFE**, YELLOW becomes **MODERATE**, RED becomes **HIGH RISK**.

## For Member 4 (server / main.c): how to call it
```c
#include "database.h"        /* team's Student struct            */
#include "academix_engine.h" /* Member 2 (safe to include together) */

/* inside the /api/save handler, after reading att, c1..c3, m1..m5 from the query: */
AxInput in = { att, {c1, c2, c3}, {m1, m2, m3, m4, m5} };
const char *err = ax_validate(&in);
if (err) { /* reply {"ok":false,"error":err} */ }
AxResult r;
ax_compute(&in, &r);

Student s = {0};             /* team's struct from database.h */
/* copy roll, name, dept from the form ... */
s.attendance = att;
s.cie_avg    = r.cie_avg;
s.sgpa       = r.sgpa;
strcpy(s.status, r.status);  /* "SAFE" / "MODERATE" / "HIGH RISK" */
add_or_update_student(s, is_update);
/* reply {"ok":true,"sgpa":r.sgpa,"status":r.status} */

/* /api/stress handler: */
double ms = ax_benchmark(10000);
/* reply {"records_processed":10000,"time_ms":ms} */
```
**Don't include** `models.h`, `grading.h` or `risk.h` in `main.c`. They define their own `Student` type, which clashes with `database.h`. `academix_engine.h`, `logger.h` and `telemetry.h` are safe to include.

## Build
Add the engine files to the team's compile command:
```
gcc -std=c99 -Iengine main.c database.c mongoose.c engine/academix_engine.c engine/grading.c engine/risk.c engine/platform.c engine/telemetry.c engine/logger.c -o academix
```
Linux: add `-lm -lpthread`.  Windows (MinGW): add `-lws2_32 -lpsapi`.

## Test (no server or database needed)
```
gcc -std=c99 -Iengine engine/test_engine.c engine/academix_engine.c engine/grading.c engine/risk.c engine/platform.c engine/telemetry.c engine/logger.c -lm -lpthread -o test_engine
./test_engine
```
Expected: `RESULT: 21 passed, 0 failed`. The default form values give **SGPA 8.69, CIE avg 23.67, SAFE**. 10,000 evaluations take about **13 ms**.
