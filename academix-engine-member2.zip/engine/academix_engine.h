/*
 * academix_engine.h — Member 2's processing engine, adapted to Academix.
 * ----------------------------------------------------------------------
 * Input  : what the admin form sends (attendance, CIE 1-3, 5 subject marks)
 * Output : SGPA, CIE average, grades, failed subjects, and the risk status
 *          "SAFE" / "MODERATE" / "HIGH RISK" from the Pure-C At-Risk Matrix.
 *
 * This header deliberately does NOT include models.h, so main.c can use it
 * together with the team's database.h (both have a struct called Student).
 */
#ifndef ACADEMIX_ENGINE_H
#define ACADEMIX_ENGINE_H

#define AX_SUBJECTS      5
#define AX_CIE_TESTS     3
#define AX_CIE_MAX       30.0f
#define AX_MARK_MAX      100.0f
#define AX_MAX_REASONS   5
#define AX_REASON_LEN    112

/* Credits shown on the form: Sub 1 (4), Sub 2 (4), Sub 3 (3), Sub 4 (3), Sub 5 (2) */
extern const int AX_CREDITS[AX_SUBJECTS];

typedef struct {
    float attendance;                 /* 0..100            */
    float cie[AX_CIE_TESTS];          /* 0..30 each        */
    float marks[AX_SUBJECTS];         /* 0..100 each       */
} AxInput;

typedef struct {
    float sgpa;                       /* credit-weighted, 10-point scale  */
    float cie_avg;                    /* out of 30                        */
    float percentage;                 /* semester marks %                 */
    char  grades[AX_SUBJECTS][4];     /* O / E / A / B / C / D / F        */
    int   failed_subjects;            /* marks below 40                   */
    float cie_slope;                  /* CIE trend in % per test (+ good) */
    float risk_score;                 /* 0 (safe) .. 100 (very risky)     */
    char  status[20];                 /* "SAFE" "MODERATE" "HIGH RISK"    */
    char  reasons[AX_MAX_REASONS][AX_REASON_LEN];
    int   reason_count;
} AxResult;

/* NULL if the input is valid, otherwise a message for the user. */
const char *ax_validate(const AxInput *in);

/* Runs grading + At-Risk Matrix. Returns 0 on success, -1 on bad input. */
int ax_compute(const AxInput *in, AxResult *out);

/* Runs n full evaluations on varied data. Returns elapsed milliseconds. */
double ax_benchmark(int n);

#endif /* ACADEMIX_ENGINE_H */
