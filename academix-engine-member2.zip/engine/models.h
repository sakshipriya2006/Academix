/*
 * models.h  —  Shared data structures (structs) for the whole project.
 * ---------------------------------------------------------------------
 * Owner : Member 2 (Backend C Developer)
 * Used by: Member 1 (fills these structs from SQLite),
 *          Member 4 (passes them between the web bridge and the engine),
 *          Member 3 (the JSON field names come from these struct fields).
 *
 * RULE FOR THE TEAM: if you need a new field, tell Member 2 first,
 * because changing a struct changes everybody's code.
 */
#ifndef MODELS_H
#define MODELS_H

/* ---------- Size limits (kept small and fixed: no malloc needed) ---------- */
#define MAX_NAME_LEN        64
#define MAX_DEPT_LEN        32
#define MAX_EMAIL_LEN       64
#define MAX_PHONE_LEN       20
#define MAX_SUBJECTS        12
#define MAX_CODE_LEN        16
#define MAX_SUBJECT_NAME    48
#define MAX_TREND_POINTS    12   /* last 12 weeks/tests used for trends   */
#define GRADE_LEN           4
#define GRADE_BAND_COUNT    7    /* O, E, A, B, C, D, F                   */
#define MAX_RISK_REASONS    5
#define RISK_REASON_LEN     112
#define MAX_CLASS_SIZE      1000

/* ---------- 1. Profile (CRUD) ---------- */
typedef struct {
    int  student_id;                 /* unique, > 0  (e.g. 202601)        */
    char name[MAX_NAME_LEN];
    char department[MAX_DEPT_LEN];   /* e.g. "CSE-AIML"                   */
    int  semester;                   /* 1 .. 8                            */
    char email[MAX_EMAIL_LEN];
    char phone[MAX_PHONE_LEN];
} Student;

/* ---------- 2. Academic records ---------- */
typedef struct {
    char  subject_code[MAX_CODE_LEN];    /* e.g. "PCC-CS301"              */
    char  subject_name[MAX_SUBJECT_NAME];
    float marks_obtained;
    float max_marks;                     /* usually 100                   */
    float pass_marks;                    /* usually 40                    */
    int   credits;                       /* used for SGPA (0 => treated 1)*/
} SubjectMark;

typedef struct {
    int classes_held;
    int classes_attended;
} Attendance;

/* Everything about one student in one bundle (what Member 1 returns). */
typedef struct {
    Student     info;
    SubjectMark subjects[MAX_SUBJECTS];
    int         subject_count;
    Attendance  attendance;
} StudentRecord;

/* ---------- 3. Output of the processing engine ---------- */
typedef struct {
    char  subject_code[MAX_CODE_LEN];
    char  subject_name[MAX_SUBJECT_NAME];
    float obtained;
    float max;
    float percent;
    char  grade[GRADE_LEN];
    float grade_point;
    int   credits;
    int   passed;                    /* 1 = cleared this subject          */
} SubjectResult;

typedef struct {
    int           student_id;
    SubjectResult subjects[MAX_SUBJECTS];
    int           subject_count;
    float         total_obtained;
    float         total_max;
    float         percentage;
    char          grade[GRADE_LEN];  /* overall letter grade              */
    float         grade_point;       /* overall grade point (from %)      */
    float         sgpa;              /* credit-weighted grade point avg   */
    int           failed_subjects;
    float         attendance_percent;
    int           attendance_shortage; /* 1 if below 75 %                 */
    int           passed;            /* final pass / fail                 */
    char          status[16];        /* "PASS", "FAIL", "NO DATA"         */
} AcademicResult;

/* ---------- 4. At-Risk Matrix ---------- */
typedef enum { TREND_ATTENDANCE = 0, TREND_MARKS = 1 } TrendKind;

/* Values in time order, oldest first. Each value is a percentage 0..100. */
typedef struct {
    float values[MAX_TREND_POINTS];
    int   count;
} TrendSeries;

typedef enum { RISK_GREEN = 0, RISK_YELLOW = 1, RISK_RED = 2 } RiskLevel;

typedef struct {
    int       student_id;
    float     score;                 /* 0 (safe) .. 100 (very risky)      */
    RiskLevel level;                 /* final colour                      */
    float     attendance_now;
    float     attendance_slope;      /* % change per period (+ good)      */
    float     marks_now;
    float     marks_slope;
    int       failed_subjects;
    int       matrix_row;            /* attendance band 0..2              */
    int       matrix_col;            /* marks band 0..2                   */
    RiskLevel matrix_level;          /* colour from the 3x3 matrix        */
    RiskLevel score_level;           /* colour from the weighted score    */
    char      reasons[MAX_RISK_REASONS][RISK_REASON_LEN];
    int       reason_count;
} RiskReport;

/* ---------- 5. Class-wise report summary ---------- */
typedef struct {
    int   total_students;
    int   evaluated;                 /* students who have marks           */
    int   passed;
    int   failed;
    float pass_rate;
    float class_average;
    float highest;
    float lowest;
    int   topper_id;
    char  topper_name[MAX_NAME_LEN];
    int   grade_count[GRADE_BAND_COUNT]; /* same order as grade table     */
    int   risk_count[3];                 /* green, yellow, red            */
} ClassSummary;

#endif /* MODELS_H */
