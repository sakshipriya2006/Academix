/* grading.c — Automated Processing Engine (Member 2). See grading.h. */
#include <string.h>
#include <stdio.h>
#include "grading.h"

/* Highest band first. The last band MUST have min_percent 0. */
static const GradeBand GRADE_TABLE[GRADE_BAND_COUNT] = {
    { 90.0f, "O", 10.0f },
    { 80.0f, "E",  9.0f },
    { 70.0f, "A",  8.0f },
    { 60.0f, "B",  7.0f },
    { 50.0f, "C",  6.0f },
    { 40.0f, "D",  5.0f },
    {  0.0f, "F",  0.0f },
};

static void copy_str(char *dst, const char *src, size_t size)
{
    if (!dst || size == 0) return;
    if (!src) src = "";
    strncpy(dst, src, size - 1);
    dst[size - 1] = '\0';
}

float grading_percent(float obtained, float max)
{
    float p;
    if (max <= 0.0f) return 0.0f;
    p = (obtained / max) * 100.0f;
    if (p < 0.0f) p = 0.0f;
    if (p > 100.0f) p = 100.0f;
    return p;
}

int grading_band_index(float percent)
{
    int i;
    for (i = 0; i < GRADE_BAND_COUNT; i++)
        if (percent >= GRADE_TABLE[i].min_percent) return i;
    return GRADE_BAND_COUNT - 1;
}

const GradeBand *grading_band(float percent)
{
    return &GRADE_TABLE[grading_band_index(percent)];
}

const char *grading_band_letter(int index)
{
    if (index < 0 || index >= GRADE_BAND_COUNT) return "?";
    return GRADE_TABLE[index].letter;
}

int grading_compute(const StudentRecord *rec, AcademicResult *out)
{
    int i, credit_sum = 0;
    float weighted_points = 0.0f;
    const GradeBand *band;

    if (!rec || !out) return -1;
    if (rec->subject_count < 0 || rec->subject_count > MAX_SUBJECTS) return -1;

    memset(out, 0, sizeof(*out));
    out->student_id    = rec->info.student_id;
    out->subject_count = rec->subject_count;

    /* Step 1: every subject on its own */
    for (i = 0; i < rec->subject_count; i++) {
        const SubjectMark *m = &rec->subjects[i];
        SubjectResult *r = &out->subjects[i];
        float max = m->max_marks > 0.0f ? m->max_marks : 100.0f;
        float obtained = m->marks_obtained;
        float pass_mark = m->pass_marks > 0.0f ? m->pass_marks
                                               : max * PASS_PERCENT / 100.0f;
        if (obtained < 0.0f) obtained = 0.0f;
        if (obtained > max)  obtained = max;

        copy_str(r->subject_code, m->subject_code, sizeof r->subject_code);
        copy_str(r->subject_name, m->subject_name, sizeof r->subject_name);
        r->obtained = obtained;
        r->max      = max;
        r->percent  = grading_percent(obtained, max);
        band        = grading_band(r->percent);
        copy_str(r->grade, band->letter, sizeof r->grade);
        r->grade_point = band->point;
        r->credits  = m->credits > 0 ? m->credits : 1;
        r->passed   = obtained >= pass_mark;

        if (!r->passed) out->failed_subjects++;
        out->total_obtained += obtained;
        out->total_max      += max;
        weighted_points     += r->grade_point * (float)r->credits;
        credit_sum          += r->credits;
    }

    /* Step 2: attendance */
    if (rec->attendance.classes_held > 0) {
        out->attendance_percent = grading_percent(
            (float)rec->attendance.classes_attended,
            (float)rec->attendance.classes_held);
        out->attendance_shortage = out->attendance_percent < ATTENDANCE_REQUIRED;
    }

    /* Step 3: no marks yet => nothing to grade */
    if (rec->subject_count == 0) {
        copy_str(out->grade, "-", sizeof out->grade);
        copy_str(out->status, "NO DATA", sizeof out->status);
        out->passed = 0;
        return 0;
    }

    /* Step 4: totals, overall grade, SGPA */
    out->percentage  = grading_percent(out->total_obtained, out->total_max);
    band             = grading_band(out->percentage);
    copy_str(out->grade, band->letter, sizeof out->grade);
    out->grade_point = band->point;
    out->sgpa        = credit_sum > 0 ? weighted_points / (float)credit_sum : 0.0f;

    /* Step 5: final decision */
    out->passed = (out->percentage >= PASS_PERCENT) && (out->failed_subjects == 0);
#if FAIL_ON_ATTENDANCE_SHORTAGE
    if (out->attendance_shortage) out->passed = 0;
#endif
    copy_str(out->status, out->passed ? "PASS" : "FAIL", sizeof out->status);
    return 0;
}

void grading_class_summary(const AcademicResult *results,
                           const char (*names)[MAX_NAME_LEN],
                           const RiskLevel *risks,
                           int n, ClassSummary *out)
{
    int i;
    float sum = 0.0f;
    if (!out) return;
    memset(out, 0, sizeof(*out));
    out->total_students = n;
    out->lowest = 0.0f;
    if (!results || n <= 0) return;

    for (i = 0; i < n; i++) {
        const AcademicResult *r = &results[i];
        if (risks && risks[i] >= RISK_GREEN && risks[i] <= RISK_RED)
            out->risk_count[risks[i]]++;
        if (r->subject_count == 0) continue;           /* NO DATA */

        if (out->evaluated == 0 || r->percentage > out->highest) {
            out->highest   = r->percentage;
            out->topper_id = r->student_id;
            copy_str(out->topper_name, names ? names[i] : "", sizeof out->topper_name);
        }
        if (out->evaluated == 0 || r->percentage < out->lowest)
            out->lowest = r->percentage;

        out->evaluated++;
        sum += r->percentage;
        if (r->passed) out->passed++; else out->failed++;
        out->grade_count[grading_band_index(r->percentage)]++;
    }
    if (out->evaluated > 0) {
        out->class_average = sum / (float)out->evaluated;
        out->pass_rate = 100.0f * (float)out->passed / (float)out->evaluated;
    }
}
