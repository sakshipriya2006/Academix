/*
 * platform.h — tiny layer that hides Windows / Linux / macOS differences.
 * Owner: Member 2.  The rest of the code never uses #ifdef _WIN32 directly
 * for locks or timers; it uses these instead.
 */
#ifndef PLATFORM_H
#define PLATFORM_H

#include <time.h>

#ifdef _WIN32
  #ifndef WIN32_LEAN_AND_MEAN
  #define WIN32_LEAN_AND_MEAN
  #endif
  #include <windows.h>
  typedef CRITICAL_SECTION eng_mutex_t;
  #define MUTEX_INIT(m)    InitializeCriticalSection(m)
  #define MUTEX_LOCK(m)    EnterCriticalSection(m)
  #define MUTEX_UNLOCK(m)  LeaveCriticalSection(m)
  #define MUTEX_DESTROY(m) DeleteCriticalSection(m)
#else
  #include <pthread.h>
  typedef pthread_mutex_t eng_mutex_t;
  #define MUTEX_INIT(m)    pthread_mutex_init((m), NULL)
  #define MUTEX_LOCK(m)    pthread_mutex_lock(m)
  #define MUTEX_UNLOCK(m)  pthread_mutex_unlock(m)
  #define MUTEX_DESTROY(m) pthread_mutex_destroy(m)
#endif

/* High-resolution monotonic clock in seconds (for timing operations). */
double platform_now_seconds(void);

/* Thread-safe local time (fills *out). */
void platform_localtime(time_t t, struct tm *out);

#endif /* PLATFORM_H */
