/* platform.c — implementation of platform.h (Member 2). */
#ifndef _WIN32
  #define _POSIX_C_SOURCE 200809L
#endif
#include "platform.h"

#ifdef _WIN32
double platform_now_seconds(void)
{
    static LARGE_INTEGER freq = {0};
    LARGE_INTEGER now;
    if (freq.QuadPart == 0) QueryPerformanceFrequency(&freq);
    QueryPerformanceCounter(&now);
    return (double)now.QuadPart / (double)freq.QuadPart;
}

void platform_localtime(time_t t, struct tm *out)
{
    localtime_s(out, &t);
}
#else
double platform_now_seconds(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + (double)ts.tv_nsec / 1e9;
}

void platform_localtime(time_t t, struct tm *out)
{
    localtime_r(&t, out);
}
#endif
