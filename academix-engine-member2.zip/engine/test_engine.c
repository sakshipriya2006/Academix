/*
 * test_engine.c — tests for Member 2's engine (no server or database needed).
 * Build + run from the project folder:
 *   gcc -std=c99 -Iengine engine/test_engine.c engine/academix_engine.c engine/grading.c \
 *       engine/risk.c engine/platform.c engine/telemetry.c engine/logger.c -lm -lpthread -o test_engine
 *   ./test_engine          (Windows: add -lpsapi, drop -lpthread, run test_engine.exe)
 */
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "academix_engine.h"
#include "telemetry.h"
#include "logger.h"

static int pass = 0, fail = 0;
#define CHECK(c) do { if (c) pass++; else { fail++; printf("  FAIL line %d: %s\n", __LINE__, #c); } } while (0)
#define NEAR(a, b) (fabs((double)(a) - (double)(b)) < 0.01)

static AxInput make(float att, float c1, float c2, float c3,
                    float m1, float m2, float m3, float m4, float m5)
{
    AxInput in;
    in.attendance = att;
    in.cie[0] = c1; in.cie[1] = c2; in.cie[2] = c3;
    in.marks[0] = m1; in.marks[1] = m2; in.marks[2] = m3; in.marks[3] = m4; in.marks[4] = m5;
    return in;
}

int main(void)
{
    AxInput in;
    AxResult r;
    TelemetrySnapshot t;
    double ms;

    /* 1. The frontend's default form values */
    in = make(84.5f, 24, 22, 25, 82, 76, 88, 79, 91);
    CHECK(ax_compute(&in, &r) == 0);
    /* E(9)x4 + A(8)x4 + E(9)x3 + A(8)x3 + O(10)x2 = 139 / 16 = 8.6875 */
    CHECK(NEAR(r.sgpa, 8.6875));
    CHECK(NEAR(r.cie_avg, 23.6667));
    CHECK(strcmp(r.grades[4], "O") == 0 && strcmp(r.grades[1], "A") == 0);
    CHECK(r.failed_subjects == 0);
    CHECK(strcmp(r.status, "SAFE") == 0);
    printf("Default form   -> SGPA %.2f | CIE avg %.2f | %s (score %.1f)\n",
           r.sgpa, r.cie_avg, r.status, r.risk_score);

    /* 2. Slipping student: attendance 68 %, CIE falling, average marks */
    in = make(68, 24, 18, 12, 58, 52, 61, 49, 55);
    CHECK(ax_compute(&in, &r) == 0);
    CHECK(r.cie_slope < 0);
    CHECK(strcmp(r.status, "MODERATE") == 0 || strcmp(r.status, "HIGH RISK") == 0);
    printf("Slipping       -> SGPA %.2f | CIE slope %.1f%%/test | %s (score %.1f)\n",
           r.sgpa, r.cie_slope, r.status, r.risk_score);

    /* 3. Failing student */
    in = make(52, 10, 8, 6, 35, 28, 42, 30, 45);
    CHECK(ax_compute(&in, &r) == 0);
    CHECK(r.failed_subjects == 3);
    CHECK(strcmp(r.status, "HIGH RISK") == 0);
    CHECK(r.reason_count >= 3);
    printf("Failing        -> SGPA %.2f | failed %d | %s (score %.1f)\n",
           r.sgpa, r.failed_subjects, r.status, r.risk_score);

    /* 4. Perfect and zero edge cases */
    in = make(100, 30, 30, 30, 100, 100, 100, 100, 100);
    CHECK(ax_compute(&in, &r) == 0 && NEAR(r.sgpa, 10) && strcmp(r.status, "SAFE") == 0);
    in = make(0, 0, 0, 0, 0, 0, 0, 0, 0);
    CHECK(ax_compute(&in, &r) == 0 && NEAR(r.sgpa, 0) && strcmp(r.status, "HIGH RISK") == 0);

    /* 5. Validation */
    in = make(101, 24, 22, 25, 82, 76, 88, 79, 91);
    CHECK(ax_validate(&in) != NULL && ax_compute(&in, &r) == -1);
    in = make(80, 31, 22, 25, 82, 76, 88, 79, 91);
    CHECK(ax_validate(&in) != NULL);
    in = make(80, 24, 22, 25, 82, 76, 88, 79, -1);
    CHECK(ax_validate(&in) != NULL);

    /* 6. Benchmark: the "10,000-Record C Benchmark" button */
    ms = ax_benchmark(10000);
    CHECK(ms > 0 && ms < 1000);
    printf("Benchmark      -> 10,000 SGPA + risk evaluations in %.3f ms\n", ms);

    /* 7. Telemetry + log line format */
    logger_set_stdout(0);
    log_event(LOG_CAT_DATABASE, LOG_SUCCESS, "Student %s saved", "AEC/CSE/25/01");
    {
        char lines[4][LOG_LINE_LEN];
        unsigned long seqs[4];
        int n = logger_copy_since(0, lines, seqs, 4);
        CHECK(n == 1 && strstr(lines[0], "[DATABASE ") && strstr(lines[0], "SUCCESS: Student AEC/CSE/25/01 saved"));
        if (n) printf("Log line       -> %s\n", lines[0]);
    }
    CHECK(telemetry_sample(&t) == 0 && t.ram_kb > 0);
    printf("Telemetry      -> RAM %ld KB, CPU %.3f s\n", t.ram_kb, t.cpu_total_sec);

    printf("\nRESULT: %d passed, %d failed\n", pass, fail);
    return fail ? 1 : 0;
}
