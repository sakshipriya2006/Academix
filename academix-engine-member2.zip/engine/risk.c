/* risk.c — Pure-C Predictive "At-Risk" Matrix (Member 2). See risk.h. */
#include <stdio.h>
#include <string.h>
#include "risk.h"
#include "grading.h"

/* Weights must add up to 1.0 */
static const float WEIGHTS[RISK_FEATURES] = {
    0.25f,  /* f1 low attendance      */
    0.20f,  /* f2 falling attendance  */
    0.25f,  /* f3 low marks           */
    0.15f,  /* f4 falling marks       */
    0.15f   /* f5 failed subjects     */
};

/* 3x3 matrix: rows = attendance band, cols = marks band.
 *              marks>=60   40..60   <40        */
static const RiskLevel RISK_MATRIX[3][3] = {
    /* att >= 75 */ { RISK_GREEN,  RISK_GREEN,  RISK_YELLOW },
    /* 60 .. 75  */ { RISK_GREEN,  RISK_YELLOW, RISK_RED    },
    /* att <  60 */ { RISK_YELLOW, RISK_RED,    RISK_RED    },
};

#define SCORE_YELLOW 30.0f
#define SCORE_RED    60.0f

static float clamp01(float x)
{
    if (x < 0.0f) return 0.0f;
    if (x > 1.0f) return 1.0f;
    return x;
}

float risk_slope(const TrendSeries *s)
{
    int i, n;
    float x_mean, y_mean = 0.0f, num = 0.0f, den = 0.0f;
    if (!s || s->count < 2) return 0.0f;
    n = s->count > MAX_TREND_POINTS ? MAX_TREND_POINTS : s->count;
    x_mean = (float)(n - 1) / 2.0f;
    for (i = 0; i < n; i++) y_mean += s->values[i];
    y_mean /= (float)n;
    for (i = 0; i < n; i++) {
        float dx = (float)i - x_mean;
        num += dx * (s->values[i] - y_mean);
        den += dx * dx;
    }
    return den > 0.0f ? num / den : 0.0f;
}

static void add_reason(RiskReport *r, const char *text)
{
    if (r->reason_count >= MAX_RISK_REASONS) return;
    snprintf(r->reasons[r->reason_count], RISK_REASON_LEN, "%s", text);
    r->reason_count++;
}

const char *risk_level_name(RiskLevel level)
{
    switch (level) {
    case RISK_GREEN:  return "GREEN";
    case RISK_YELLOW: return "YELLOW";
    case RISK_RED:    return "RED";
    }
    return "UNKNOWN";
}

const char *risk_level_hex(RiskLevel level)
{
    switch (level) {
    case RISK_GREEN:  return "#22c55e";
    case RISK_YELLOW: return "#eab308";
    case RISK_RED:    return "#ef4444";
    }
    return "#94a3b8";
}

int risk_evaluate(const StudentRecord *rec, const AcademicResult *result,
                  const TrendSeries *att, const TrendSeries *marks,
                  RiskReport *out)
{
    float f[RISK_FEATURES];
    float score = 0.0f;
    int i;
    char buf[RISK_REASON_LEN];

    if (!rec || !result || !out) return -1;
    memset(out, 0, sizeof(*out));
    out->student_id = rec->info.student_id;

    /* --- Current values --- */
    if (rec->attendance.classes_held > 0)
        out->attendance_now = result->attendance_percent;
    else if (att && att->count > 0)
        out->attendance_now = att->values[att->count - 1];
    else
        out->attendance_now = 100.0f;           /* no data: assume fine */

    if (result->subject_count > 0)
        out->marks_now = result->percentage;
    else if (marks && marks->count > 0)
        out->marks_now = marks->values[marks->count - 1];
    else
        out->marks_now = 100.0f;

    out->attendance_slope = risk_slope(att);
    out->marks_slope      = risk_slope(marks);
    out->failed_subjects  = result->failed_subjects;

    /* --- Feature vector (each 0..1) --- */
    f[0] = clamp01((ATTENDANCE_REQUIRED - out->attendance_now) / 40.0f);
    f[1] = clamp01(-out->attendance_slope / 5.0f);  /* -5 %/period = max  */
    f[2] = clamp01((60.0f - out->marks_now) / 30.0f);
    f[3] = clamp01(-out->marks_slope / 8.0f);       /* -8 %/test   = max  */
    f[4] = clamp01((float)out->failed_subjects / 3.0f);

    /* --- Weighted score (dot product W . F) --- */
    for (i = 0; i < RISK_FEATURES; i++) score += WEIGHTS[i] * f[i];
    out->score = score * 100.0f;
    out->score_level = out->score >= SCORE_RED    ? RISK_RED
                     : out->score >= SCORE_YELLOW ? RISK_YELLOW
                     : RISK_GREEN;

    /* --- 3x3 matrix lookup --- */
    out->matrix_row = out->attendance_now >= 75.0f ? 0
                    : out->attendance_now >= 60.0f ? 1 : 2;
    out->matrix_col = out->marks_now >= 60.0f ? 0
                    : out->marks_now >= 40.0f ? 1 : 2;
    out->matrix_level = RISK_MATRIX[out->matrix_row][out->matrix_col];

    /* --- Final: the worse of the two --- */
    out->level = out->score_level > out->matrix_level ? out->score_level
                                                      : out->matrix_level;

    /* --- Human-readable reasons for the UI --- */
    if (out->attendance_now < ATTENDANCE_REQUIRED) {
        snprintf(buf, sizeof buf, "Attendance %.1f%% is below the %.0f%% rule",
                 out->attendance_now, ATTENDANCE_REQUIRED);
        add_reason(out, buf);
    }
    if (out->attendance_slope <= -1.0f) {
        snprintf(buf, sizeof buf, "Attendance falling %.1f%% per week",
                 -out->attendance_slope);
        add_reason(out, buf);
    }
    if (out->marks_now < 60.0f) {
        snprintf(buf, sizeof buf, "Marks average %.1f%% is weak", out->marks_now);
        add_reason(out, buf);
    }
    if (out->marks_slope <= -2.0f) {
        snprintf(buf, sizeof buf, "Grades slipping %.1f%% per test", -out->marks_slope);
        add_reason(out, buf);
    }
    if (out->failed_subjects > 0) {
        snprintf(buf, sizeof buf, "Failing %d subject%s", out->failed_subjects,
                 out->failed_subjects == 1 ? "" : "s");
        add_reason(out, buf);
    }
    if (out->reason_count == 0)
        add_reason(out, "On track: attendance and grades are stable");
    return 0;
}
