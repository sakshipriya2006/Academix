/* logger.c — Terminal Mirror log source (Member 2). See logger.h. */
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <time.h>
#include "logger.h"
#include "platform.h"

static eng_mutex_t   g_lock;
static int           g_ready = 0;
static int           g_stdout = 1;
static char          g_ring[LOG_RING_SIZE][LOG_LINE_LEN];
static unsigned long g_ring_seq[LOG_RING_SIZE];
static unsigned long g_seq = 0;          /* last sequence number used */
static LogListener   g_listener = NULL;
static void         *g_listener_user = NULL;

static const char *CAT_NAMES[] = {
    "DATABASE", "ENGINE", "RISK", "TELEMETRY", "BENCHMARK", "SERVER"
};
static const char *LEVEL_NAMES[] = { "INFO", "SUCCESS", "WARN", "ERROR" };

void logger_init(void)
{
    if (g_ready) return;
    MUTEX_INIT(&g_lock);
    g_ready = 1;
}

void logger_shutdown(void)
{
    if (!g_ready) return;
    MUTEX_DESTROY(&g_lock);
    g_ready = 0;
    g_listener = NULL;
}

void logger_set_listener(LogListener fn, void *user)
{
    if (!g_ready) logger_init();
    MUTEX_LOCK(&g_lock);
    g_listener = fn;
    g_listener_user = user;
    MUTEX_UNLOCK(&g_lock);
}

void logger_set_stdout(int enabled) { g_stdout = enabled; }

unsigned long log_event(LogCategory cat, LogLevel level, const char *fmt, ...)
{
    char msg[LOG_LINE_LEN - 40];
    char line[LOG_LINE_LEN];
    struct tm tmv;
    va_list ap;
    unsigned long seq;
    LogListener fn;
    void *user;
    int ci = (cat >= LOG_CAT_DATABASE && cat <= LOG_CAT_SERVER) ? (int)cat : 1;
    int li = (level >= LOG_INFO && level <= LOG_ERROR) ? (int)level : 0;

    if (!g_ready) logger_init();

    va_start(ap, fmt);
    vsnprintf(msg, sizeof msg, fmt, ap);
    va_end(ap);

    platform_localtime(time(NULL), &tmv);
    snprintf(line, sizeof line, "[%s %02d:%02d:%02d] %s: %s",
             CAT_NAMES[ci], tmv.tm_hour, tmv.tm_min, tmv.tm_sec,
             LEVEL_NAMES[li], msg);

    MUTEX_LOCK(&g_lock);
    seq = ++g_seq;
    memcpy(g_ring[seq % LOG_RING_SIZE], line, sizeof line);
    g_ring_seq[seq % LOG_RING_SIZE] = seq;
    fn = g_listener;
    user = g_listener_user;
    if (g_stdout) { fputs(line, stdout); fputc('\n', stdout); fflush(stdout); }
    MUTEX_UNLOCK(&g_lock);

    if (fn) fn(line, seq, user);      /* outside the lock: no deadlocks */
    return seq;
}

int logger_copy_since(unsigned long after_seq, char lines[][LOG_LINE_LEN],
                      unsigned long *seqs, int max)
{
    unsigned long first, s;
    int n = 0;
    if (!lines || max <= 0) return 0;
    if (!g_ready) logger_init();

    MUTEX_LOCK(&g_lock);
    first = after_seq + 1;
    if (g_seq >= LOG_RING_SIZE && first <= g_seq - LOG_RING_SIZE)
        first = g_seq - LOG_RING_SIZE + 1;            /* older lines are gone */
    if (g_seq >= first && g_seq - first + 1 > (unsigned long)max)
        first = g_seq - (unsigned long)max + 1;        /* keep the newest */
    for (s = first; s <= g_seq && n < max; s++) {
        memcpy(lines[n], g_ring[s % LOG_RING_SIZE], LOG_LINE_LEN);
        if (seqs) seqs[n] = g_ring_seq[s % LOG_RING_SIZE];
        n++;
    }
    MUTEX_UNLOCK(&g_lock);
    return n;
}

unsigned long logger_latest_seq(void)
{
    unsigned long s;
    if (!g_ready) logger_init();
    MUTEX_LOCK(&g_lock);
    s = g_seq;
    MUTEX_UNLOCK(&g_lock);
    return s;
}
