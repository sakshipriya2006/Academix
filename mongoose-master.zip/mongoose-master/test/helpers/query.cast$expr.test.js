'use strict';

const mongoose = require('../common').mongoose;
const { Schema } = mongoose;
const assert = require('assert');
const cast$expr = require('../../lib/helpers/query/cast$expr');

describe('castexpr', function() {
  it('casts comparisons', function() {
    const testSchema = new Schema({ date: Date, spent: Number, budget: Number, nums: [Number] });

    let res = cast$expr({ $eq: ['$date', '2021-06-01'] }, testSchema);
    assert.deepEqual(res, { $eq: ['$date', new Date('2021-06-01')] });

    res = cast$expr({ $eq: [{ $year: '$date' }, 2021] }, testSchema);
    assert.deepStrictEqual(res, { $eq: [{ $year: '$date' }, 2021] });

    res = cast$expr({ $eq: [{ $year: '$date' }, '2021'] }, testSchema);
    assert.deepStrictEqual(res, { $eq: [{ $year: '$date' }, 2021] });

    res = cast$expr({ $eq: [{ $year: '$date' }, { $literal: '2021' }] }, testSchema);
    assert.deepStrictEqual(res, { $eq: [{ $year: '$date' }, { $literal: 2021 }] });

    res = cast$expr({ $eq: [{ $year: '$date' }, { $literal: '2021' }] }, testSchema);
    assert.deepStrictEqual(res, { $eq: [{ $year: '$date' }, { $literal: 2021 }] });

    res = cast$expr({ $gt: ['$spent', '$budget'] }, testSchema);
    assert.deepStrictEqual(res, { $gt: ['$spent', '$budget'] });

    res = cast$expr({ $gt: [{ $last: '$nums' }, '42'] }, testSchema);
    assert.deepStrictEqual(res, { $gt: [{ $last: '$nums' }, 42] });
  });

  it('casts conditions', function() {
    const testSchema = new Schema({ price: Number, qty: Number });

    let discountedPrice = {
      $cond: {
        if: { $gte: ['$qty', { $floor: '100' }] },
        then: { $multiply: ['$price', '0.5'] },
        else: { $multiply: ['$price', '0.75'] }
      }
    };
    let res = cast$expr({ $lt: [discountedPrice, 5] }, testSchema);
    assert.deepStrictEqual(res, {
      $lt: [
        {
          $cond: {
            if: { $gte: ['$qty', { $floor: 100 }] },
            then: { $multiply: ['$price', 0.5] },
            else: { $multiply: ['$price', 0.75] }
          }
        },
        5
      ]
    });

    discountedPrice = {
      $cond: {
        if: { $and: [{ $gte: ['$qty', { $floor: '100' }] }] },
        then: { $multiply: ['$price', '0.5'] },
        else: { $multiply: ['$price', '0.75'] }
      }
    };
    res = cast$expr({ $lt: [discountedPrice, 5] }, testSchema);
    assert.deepStrictEqual(res, {
      $lt: [
        {
          $cond: {
            if: { $and: [{ $gte: ['$qty', { $floor: 100 }] }] },
            then: { $multiply: ['$price', 0.5] },
            else: { $multiply: ['$price', 0.75] }
          }
        },
        5
      ]
    });
  });

  it('casts boolean expressions', function() {
    const testSchema = new Schema({ date: Date, spent: Number, budget: Number });

    const res = cast$expr({ $and: [{ $eq: [{ $year: '$date' }, '2021'] }] }, testSchema);
    assert.deepStrictEqual(res, { $and: [{ $eq: [{ $year: '$date' }, 2021] }] });
  });

  it('cast errors', function() {
    const testSchema = new Schema({ date: Date, spent: Number, budget: Number });

    assert.throws(() => {
      cast$expr({ $eq: [{ $year: '$date' }, 'not a number'] }, testSchema);
    }, /Cast to Number failed/);
  });

  it('casts $in', function() {
    const testSchema = new Schema({ nums: [Number], docs: [new Schema({ prop: Number }, { _id: false })] });

    let res = cast$expr({ $in: ['42', '$nums'] }, testSchema);
    assert.deepStrictEqual(res, { $in: [42, '$nums'] });

    res = cast$expr({ $in: [{ prop: '42' }, '$docs'] }, testSchema);
    res.$in[0] = res.$in[0].toBSON(); // So `deepStrictEqual()` doesn't complain about subdoc internals
    assert.deepStrictEqual(res, { $in: [{ prop: 42 }, '$docs'] });
  });

  it('casts $in when the search value is an expression', function() {
    const testSchema = new Schema({ num: Number, nums: [Number], owner: 'ObjectId', ids: ['ObjectId'] });

    let res = cast$expr({ $in: ['$num', '$nums'] }, testSchema);
    assert.deepStrictEqual(res, { $in: ['$num', '$nums'] });

    res = cast$expr({ $in: ['$owner', '$ids'] }, testSchema);
    assert.deepStrictEqual(res, { $in: ['$owner', '$ids'] });

    res = cast$expr({ $in: [{ $multiply: ['$num', '2'] }, '$nums'] }, testSchema);
    assert.deepStrictEqual(res, { $in: [{ $multiply: ['$num', 2] }, '$nums'] });

    res = cast$expr({ $in: [{ $literal: '42' }, '$nums'] }, testSchema);
    assert.deepStrictEqual(res, { $in: [{ $literal: 42 }, '$nums'] });

    const Test = mongoose.model('CastExprInDocument', new Schema({ name: String }));
    const doc = new Test({ name: 'test' });
    res = cast$expr({ $in: [doc, '$ids'] }, testSchema);
    assert.ok(res.$in[0] instanceof mongoose.Types.ObjectId);
    assert.strictEqual(res.$in[0].toHexString(), doc._id.toHexString());
  });

  it('casts $not (gh-11689)', function() {
    const testSchema = new Schema({ nums: [Number], docs: [new Schema({ prop: Number }, { _id: false })] });

    const res = cast$expr({ $not: { $in: ['42', '$nums'] } }, testSchema);
    assert.deepStrictEqual(res, { $not: { $in: [42, '$nums'] } });
  });

  it('casts $round (gh-13881)', function() {
    const testSchema = new Schema({ value: Number });

    let res = cast$expr({ $eq: [{ $round: ['$value', '00'] }, 2] }, testSchema);
    assert.deepStrictEqual(res, { $eq: [{ $round: ['$value', 0] }, 2] });

    res = cast$expr({ $eq: [{ $round: ['$value'] }, 2] }, testSchema);
    assert.deepStrictEqual(res, { $eq: [{ $round: ['$value'] }, 2] });
  });

  it('casts nested expressions on the right-hand side of a comparison', function() {
    const testSchema = new Schema({ isActive: Boolean, count: Number, nums: [Number] });

    let res = cast$expr({ $eq: ['$isActive', { $gt: ['$count', '5'] }] }, testSchema);
    assert.deepStrictEqual(res, { $eq: ['$isActive', { $gt: ['$count', 5] }] });

    res = cast$expr({ $eq: ['$isActive', { $in: ['42', '$nums'] }] }, testSchema);
    assert.deepStrictEqual(res, { $eq: ['$isActive', { $in: [42, '$nums'] }] });
  });

  it('casts $switch (gh-14751)', function() {
    const testSchema = new Schema({
      name: String,
      scores: [Number]
    });
    const res = cast$expr({
      $eq: [
        {
          $switch: {
            branches: [{ case: { $eq: ['$$NOW', '$$NOW'] }, then: true }],
            default: false
          }
        },
        true
      ]
    }, testSchema);
    assert.deepStrictEqual(res, {
      $eq: [
        {
          $switch: {
            branches: [{ case: { $eq: ['$$NOW', '$$NOW'] }, then: true }],
            default: false
          }
        },
        true
      ]
    });
  });

  it('casts case and then expressions in $switch branches', function() {
    const testSchema = new Schema({ age: Number, score: Number });

    const res = cast$expr({
      $switch: {
        branches: [{ case: { $gte: ['$age', '18'] }, then: { $multiply: ['$score', '2'] } }],
        default: '$score'
      }
    }, testSchema);
    assert.deepStrictEqual(res, {
      $switch: {
        branches: [{ case: { $gte: ['$age', 18] }, then: { $multiply: ['$score', 2] } }],
        default: '$score'
      }
    });

    const res2 = cast$expr({ $switch: { branches: [{ case: { $gte: ['$age', '18'] }, then: undefined }] } }, testSchema);
    assert.deepStrictEqual(res2, { $switch: { branches: [{ case: { $gte: ['$age', 18] } }] } });
  });
});
