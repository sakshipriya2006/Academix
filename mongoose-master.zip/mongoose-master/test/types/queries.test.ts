import mongoose, {
  HydratedDocument,
  Schema,
  model,
  Document,
  Types,
  Query,
  Model,
  QueryWithHelpers,
  PopulatedDoc,
  UpdateQuery,
  UpdateQueryKnownOnly,
  InferRawDocType,
  InferSchemaType,
  ProjectionFields,
  QueryOptions,
  ProjectionType,
  QueryFilter
} from 'mongoose';
import { Condition, ModifyResult, ObjectId } from 'mongodb';
import { autoTypedModel } from './models.test';
import { expect } from 'tstyche';

interface QueryHelpers {
  _byName(this: QueryWithHelpers<any, ITest, QueryHelpers>, name: string): QueryWithHelpers<Array<ITest>, ITest, QueryHelpers>;
  byName(this: QueryWithHelpers<any, ITest, QueryHelpers>, name: string): QueryWithHelpers<Array<ITest>, ITest, QueryHelpers>;
}

const childSchema = new Schema({ name: String });
const ChildModel = model<Child>('Child', childSchema);

const schema: Schema<ITest, Model<ITest, QueryHelpers>, {}, QueryHelpers> = new Schema({
  name: { type: 'String' },
  tags: [String],
  child: { type: 'ObjectId', ref: 'Child' },
  docs: [{ _id: 'ObjectId', id: Number, tags: [String] }],
  endDate: Date
});

schema.query._byName = function(name: string): QueryWithHelpers<ITest[], ITest, QueryHelpers> {
  return this.find({ name });
};

schema.query.byName = function(name: string): QueryWithHelpers<ITest[], ITest, QueryHelpers> {
  expect(this).type.not.toHaveProperty('notAQueryHelper');
  return this._byName(name);
};

interface Child {
  name: string;
}
interface ISubdoc {
  myId?: Types.ObjectId;
  id?: number;
  tags?: string[];
  profiles: {
    name?: string
  }
}

interface ITest {
  _id: Types.ObjectId;
  name?: string;
  age?: number;
  parent?: Types.ObjectId;
  child?: PopulatedDoc<HydratedDocument<Child>>,
  tags?: string[];
  docs?: ISubdoc[];
  endDate?: Date;
}

expect<mongoose.WithLevel1NestedPaths<ITest>['docs.id']>().type.toBe<number | undefined>();

const Test = model<ITest, Model<ITest, QueryHelpers>>('Test', schema);

const schemaWithQueryHelper = new Schema({ name: String }).queryHelper('byName', function(name: string) {
  return this.where({ name });
});
const ModelWithQueryHelper = model('ModelWithQueryHelper', schemaWithQueryHelper);
ModelWithQueryHelper.find().byName('test').exec();

Test.find({}, {}, { populate: { path: 'child', model: ChildModel, match: true } }).exec().then((res: Array<ITest>) => console.log(res));

Test.find({}, { name: 1 }).then(docs => {
  expect(docs[0]).type.toHaveProperty('name');
  expect(docs[0]).type.not.toHaveProperty('age');
  expect(docs[0]).type.toHaveProperty('_id');
});
Test.findOne({}, { name: 1 }).then(doc => {
  expect(doc!).type.toHaveProperty('name');
  expect(doc!).type.not.toHaveProperty('age');
  expect(doc!).type.toHaveProperty('_id');
});
Test.find({}, undefined, { projection: { name: 1 } }).then(docs => {
  expect(docs[0]).type.toHaveProperty('name');
  expect(docs[0]).type.not.toHaveProperty('age');
  expect(docs[0]).type.toHaveProperty('_id');
});
Test.findOne({}, undefined, { projection: { name: 1 } }).then(doc => {
  expect(doc!).type.toHaveProperty('name');
  expect(doc!).type.not.toHaveProperty('age');
  expect(doc!).type.toHaveProperty('_id');
});
Test.find({}, { name: 1 }, { lean: true }).then(docs => {
  expect(docs[0]).type.toHaveProperty('name');
  expect(docs[0]).type.not.toHaveProperty('age');
  expect(docs[0]).type.toHaveProperty('_id');
});
Test.find({}, undefined, { projection: { age: 0, _id: 1 }, lean: true }).then(docs => {
  expect(docs[0]).type.toHaveProperty('name');
  expect(docs[0]).type.not.toHaveProperty('age');
  expect(docs[0]).type.toHaveProperty('_id');
});
Test.findOne({}, { name: 1 }, { lean: true }).then(doc => {
  expect(doc!).type.toHaveProperty('name');
  expect(doc!).type.not.toHaveProperty('age');
  expect(doc!).type.toHaveProperty('_id');
});
Test.findOne({}, undefined, { projection: { age: 0, _id: 1 }, lean: true }).then(doc => {
  expect(doc!).type.toHaveProperty('name');
  expect(doc!).type.not.toHaveProperty('age');
  expect(doc!).type.toHaveProperty('_id');
});
Test.findById(new Types.ObjectId(), { name: 1 }, { lean: true }).then(doc => {
  expect(doc!).type.toHaveProperty('name');
  expect(doc!).type.not.toHaveProperty('age');
  expect(doc!).type.toHaveProperty('_id');
});
Test.findAndCount({}, { name: 1 }, { sort: { name: 1 }, limit: 1, lean: true }).then(([docs]) => {
  expect(docs[0]).type.toHaveProperty('name');
  expect(docs[0]).type.not.toHaveProperty('age');
  expect(docs[0]).type.toHaveProperty('_id');
});
Test.find({}, { name: 1 }).lean().then(docs => {
  expect(docs[0]).type.toHaveProperty('name');
  expect(docs[0]).type.not.toHaveProperty('age');
  expect(docs[0]).type.toHaveProperty('_id');
});
Test.findOne({}, { name: 1 }).lean().then(doc => {
  expect(doc!).type.toHaveProperty('name');
  expect(doc!).type.not.toHaveProperty('age');
  expect(doc!).type.toHaveProperty('_id');
});
Test.findOne({}, undefined, { projection: { name: 1 } }).lean().then(doc => {
  expect(doc!).type.toHaveProperty('name');
  expect(doc!).type.not.toHaveProperty('age');
  expect(doc!).type.toHaveProperty('_id');
});
Test.findOne({}, { age: 0 }).lean().then(doc => {
  expect(doc!).type.toHaveProperty('name');
  expect(doc!).type.not.toHaveProperty('age');
  expect(doc!).type.toHaveProperty('_id');
});
Test.findOneAndUpdate({}, {}, { projection: { name: 1 } }).lean().then(doc => {
  expect(doc!).type.toHaveProperty('name');
  expect(doc!).type.not.toHaveProperty('age');
  expect(doc!).type.toHaveProperty('_id');
});
Test.findOneAndDelete({}, { projection: { name: 1 } }).lean().then(doc => {
  expect(doc!).type.toHaveProperty('name');
  expect(doc!).type.not.toHaveProperty('age');
  expect(doc!).type.toHaveProperty('_id');
});
Test.findOne({}, { name: 1, _id: 0 }).then(doc => {
  expect(doc!).type.toHaveProperty('name');
  expect(doc!).type.not.toHaveProperty('age');
  expect(doc!).type.not.toHaveProperty('_id');
});
Test.findOne({}, { _id: 0 }).then(doc => {
  expect(doc!).type.toHaveProperty('name');
  expect(doc!).type.toHaveProperty('age');
  expect(doc!).type.not.toHaveProperty('_id');
});
Test.findOne({}, { _id: 0 }).lean().then(doc => {
  expect(doc!).type.toHaveProperty('name');
  expect(doc!).type.toHaveProperty('age');
  expect(doc!).type.not.toHaveProperty('_id');
});
Test.findOne({}, { _id: 1 }).then(doc => {
  expect(doc!).type.not.toHaveProperty('name');
  expect(doc!).type.not.toHaveProperty('age');
  expect(doc!).type.toHaveProperty('_id');
});
Test.findOne({}, { age: 0, _id: 1 }).then(doc => {
  expect(doc!).type.toHaveProperty('name');
  expect(doc!).type.not.toHaveProperty('age');
  expect(doc!).type.toHaveProperty('_id');
});
Test.findOne({}, { _id: true, age: false }).then(doc => {
  expect(doc!).type.toHaveProperty('name');
  expect(doc!).type.not.toHaveProperty('age');
  expect(doc!).type.toHaveProperty('_id');
});
Test.findOne({}, { _id: true }).then(doc => {
  expect(doc!).type.not.toHaveProperty('name');
  expect(doc!).type.not.toHaveProperty('age');
  expect(doc!).type.toHaveProperty('_id');
});

type ProjectionDoc = { _id: string; name: string; age: number };
expect<mongoose.ApplyProjection<ProjectionDoc, { _id: 1; age: 0 }>>().type.toBe<{ _id: string; name: string }>();
expect<mongoose.ApplyProjection<ProjectionDoc, { _id: 0; age: 0 }>>().type.toBe<{ name: string }>();
expect<mongoose.ApplyProjection<ProjectionDoc, { _id: false }>>().type.toBe<{ name: string; age: number }>();

type ProjectionSliceDoc = { _id: string; name: string; tags: string[]; meta: { title: string; list: number[] } };
type NestedProjectionDoc = { _id: string; name: string; meta: { title: string; hidden: boolean } };
expect<mongoose.ApplyProjection<NestedProjectionDoc, { name: 1; 'meta.title': 1 }>>().type.toBe<{ _id: string; name: string; meta: { title: string } }>();
expect<mongoose.ApplyProjection<NestedProjectionDoc, { score: { $meta: 'textScore' } }>>()
  .type.toBe<NestedProjectionDoc & { score?: number }>();
expect<mongoose.ApplyProjection<NestedProjectionDoc, { age: 0, textScore: { $meta: 'textScore' } }>>()
  .type.toBe<NestedProjectionDoc & { textScore?: number }>();
expect<mongoose.ApplyProjection<NestedProjectionDoc, { name: 1, score: { $meta: 'textScore' } }>>()
  .type.toBe<{ _id: string; name: string; score?: number }>();
expect<mongoose.ApplyProjection<NestedProjectionDoc, { _id: 1, key: { $meta: 'indexKey' } }>>()
  .type.toBe<{ _id: string; key?: any }>();
// MongoDB overwrites `name` with the score, but hydrated documents cast it back to a string
expect<mongoose.ApplyProjection<NestedProjectionDoc, { name: { $meta: 'textScore' } }>>().type.toBe<NestedProjectionDoc>();
expect<mongoose.ApplyProjection<NestedProjectionDoc, { _id: 1, name: { $meta: 'textScore' } }>>().type.toBe<{ _id: string; name: string }>();
expect<mongoose.ApplyProjection<NestedProjectionDoc, { 'name.score': { $meta: 'textScore' } }>>().type.toBe<NestedProjectionDoc>();
expect<mongoose.ApplyProjection<NestedProjectionDoc, { 'meta.score': { $meta: 'textScore' } }>>()
  .type.toBe<{ _id: string; name: string; meta: { title: string; hidden: boolean; score?: number } }>();
expect<mongoose.ApplyProjection<NestedProjectionDoc, { name: 1, 'meta.score': { $meta: 'textScore' } }>>()
  .type.toBe<{ _id: string; name: string; meta: { score?: number } }>();
expect<mongoose.ApplyProjection<NestedProjectionDoc, { 'meta.hidden': 0, 'meta.score': { $meta: 'textScore' } }>>()
  .type.toBe<{ _id: string; name: string; meta: { title: string; score?: number } }>();
expect<mongoose.ApplyProjection<NestedProjectionDoc, { 'foo.bar.score': { $meta: 'textScore' } }>>()
  .type.toBe<NestedProjectionDoc & { foo?: { bar?: { score?: number } } }>();
// Inclusion projections add `| undefined` to optional parents, same as `{ 'meta.title': 1 }` with an optional `meta`
expect<mongoose.ApplyProjection<NestedProjectionDoc, { name: 1, 'foo.bar.score': { $meta: 'textScore' } }>>()
  .type.toBe<{ _id: string; name: string; foo?: { bar?: { score?: number } | undefined } | undefined }>();
expect<mongoose.ApplyProjection<{ _id: string; arr: { a: number }[] }, { 'arr.score': { $meta: 'textScore' } }>>()
  .type.toBe<{ _id: string; arr: { a: number; score?: number }[] }>();
expect<mongoose.ApplyProjection<NestedProjectionDoc, { 'meta.title': 1 }>>().type.toBe<{ _id: string; meta: { title: string } }>();
expect<mongoose.ApplyProjection<NestedProjectionDoc, { 'meta.hidden': 0 }>>().type.toBe<{ _id: string; name: string; meta: { title: string } }>();
expect<mongoose.ApplyProjection<{ _id: string; meta: any }, { 'meta.title': 1 }>>().type.toBe<{ _id: string; meta: any }>();
expect<mongoose.ApplyProjection<any, { name: 1; 'meta.title': 1 }>>().type.toBe<{ _id: any; name: any; meta: any }>();

expect<mongoose.ApplyProjection<ProjectionDoc, Record<string, 0>>>().type.toBe<ProjectionDoc>();
expect<mongoose.ApplyProjection<ProjectionDoc, Record<string, 1>>>().type.toBe<ProjectionDoc>();

expect<mongoose.ApplyProjection<Record<string, any>, { name: 1 }>['name']>().type.toBe<any>();
expect<mongoose.ApplyProjection<{ _id: string; meta: Record<string, string> }, { 'meta.foo': 1 }>>().type.toBe<{ _id: string; meta: { foo: string } }>();
expect<mongoose.ApplyProjection<{ _id: string; meta: Record<string, { a: string; b: number }> }, { 'meta.foo.a': 1 }>>().type.toBe<{ _id: string; meta: { foo: { a: string } } }>();

type MongooseArrayDoc = { _id: string; arr: Types.Array<{ a: string; b: number }> };
expect<mongoose.ApplyProjection<MongooseArrayDoc, { 'arr.b': 1 }>>().type.toBe<MongooseArrayDoc>();
expect<mongoose.ApplyProjection<MongooseArrayDoc, { 'arr.b': 0 }>>().type.toBe<MongooseArrayDoc>();

type LeafDoc = {
  _id: string;
  links: Map<string, string>;
  hydratedLinks: Types.Map<string>;
  at: Date;
  ref: Types.ObjectId;
  price: Types.Decimal128;
  uuid: Types.UUID;
};
// `size` is a valid map key
expect<mongoose.ApplyProjection<LeafDoc, { 'links.size': 1 }>['links']>().type.toBe<Map<string, string>>();
expect<mongoose.ApplyProjection<LeafDoc, { 'links.size': 0 }>['links']>().type.toBe<Map<string, string>>();
expect<mongoose.ApplyProjection<LeafDoc, { 'hydratedLinks.size': 1 }>['hydratedLinks']>().type.toBe<Types.Map<string>>();
// Exclusive projection underneath a scalar does not exclude the scalar property
expect<mongoose.ApplyProjection<LeafDoc, { 'ref.id': 0 }>['ref']>().type.toBe<Types.ObjectId>();
expect<mongoose.ApplyProjection<LeafDoc, { 'uuid.buffer': 0 }>['uuid']>().type.toBe<Types.UUID>();
// Inclusive projection underneath scalar excludes the scalar property
expect<mongoose.ApplyProjection<LeafDoc, { 'at.getTime': 1 }>>().type.not.toHaveProperty('at');
expect<mongoose.ApplyProjection<LeafDoc, { 'ref.id': 1 }>>().type.not.toHaveProperty('ref');
expect<mongoose.ApplyProjection<LeafDoc, { 'price.bytes': 1 }>>().type.not.toHaveProperty('price');
expect<
  mongoose.ApplyProjection<
    { _id: string; note: string | null },
    { 'note.x': 1 }
  >
>().type.toBe<{ _id: string }>();
expect<
  mongoose.ApplyProjection<
    { _id: string; meta: { title: string } },
    { 'meta.typo': 1 }
  >
>().type.toBe<{ _id: string; meta: Record<string, never> }>();
expect<
  mongoose.ApplyProjection<
    { _id: string; meta: { note: string; title: string } },
    { 'meta.note.x': 1 }
  >
>().type.toBe<{ _id: string; meta: Record<string, never> }>();
expect<mongoose.ApplyProjection<{ _id: string; items: { a: string }[] }, { 'items.typo': 1 }>>().type.toBe<{ _id: string; items: Record<string, never>[] }>();
expect<mongoose.ApplyProjection<ProjectionDoc, { typo: 1 }>>().type.toBe<{ _id: string }>();

// Inclusive projection underneath array of scalars makes an array of nevers - `never[]`
// means an array that must always be empty. That matches the MongoDB server - `tags.x: 1`
// always returns empty array below.
expect<mongoose.ApplyProjection<{ _id: string; tags: string[] }, { 'tags.x': 1 }>>().type.toBe<{ _id: string; tags: never[] }>();
expect<mongoose.ApplyProjection<{ _id: string; tags: string[][] }, { 'tags.x': 1 }>>().type.toBe<{ _id: string; tags: never[][] }>();
// If there's a union, projection should drill into the union
expect<
  mongoose.ApplyProjection<
    { _id: string; items: Array<string | { a: string; b: number } | null> },
    { 'items.a': 1 }
  >
>().type.toBe<{ _id: string; items: { a: string }[] }>();
expect<mongoose.ApplyProjection<{ _id: string; sub: { a: string; b: number } | null }, { 'sub.a': 1 }>>().type.toBe<{ _id: string; sub: { a: string } | undefined }>();
expect<mongoose.ApplyProjection<{ _id: string; sub: string | { a: string; b: number } }, { 'sub.a': 1 }>>().type.toBe<{ _id: string; sub: { a: string } | undefined }>();

type ErrorShapedDoc = { _id: string; err: { name: string; message: string; code: number } };
expect<mongoose.ApplyProjection<ErrorShapedDoc, { 'err.code': 1 }>>().type.toBe<{ _id: string; err: { code: number } }>();
expect<mongoose.ApplyProjection<ErrorShapedDoc, { 'err.code': 0 }>>().type.toBe<{ _id: string; err: { name: string; message: string } }>();

expect<mongoose.ApplyProjection<ProjectionSliceDoc, { name: 1; tags: { $slice: 1 } }>>().type.toBe<{ _id: string; name: string; tags: string[] }>();
expect<mongoose.ApplyProjection<ProjectionSliceDoc, { _id: 1; tags: { $slice: 1 } }>>().type.toBe<{ _id: string; tags: string[] }>();
expect<mongoose.ApplyProjection<ProjectionSliceDoc, { 'meta.title': 1; 'meta.list': { $slice: 1 } }>>().type.toBe<{ _id: string; meta: { title: string; list: number[] } }>();
expect<mongoose.ApplyProjection<ProjectionSliceDoc, { name: 1; 'meta.list': { $slice: 1 } }>>().type.toBe<{ _id: string; name: string; meta: { list: number[] } }>();
expect<mongoose.ApplyProjection<ProjectionSliceDoc, { tags: { $slice: 1 } }>>().type.toBe<ProjectionSliceDoc>();
expect<mongoose.ApplyProjection<ProjectionSliceDoc, { name: 0; tags: { $slice: 1 } }>>().type.toBe<Omit<ProjectionSliceDoc, 'name'>>();
expect<mongoose.ApplyProjection<ProjectionSliceDoc, { _id: 1; name: 0 }>>().type.toBe<Omit<ProjectionSliceDoc, 'name'>>();

type SubdocProjectionDoc = {
  _id: string;
  sub: mongoose.HydratedSingleSubdocument<{ a: string; b: number }>;
  author: mongoose.HydratedDocument<{ name: string; age: number }>;
};
expect<mongoose.ApplyProjection<SubdocProjectionDoc, { 'sub.a': 1 }>['sub']>().type.toBe<SubdocProjectionDoc['sub']>();
expect<mongoose.ApplyProjection<SubdocProjectionDoc, { 'sub.a': 0 }>['sub']>().type.toBe<SubdocProjectionDoc['sub']>();
expect<mongoose.ApplyProjection<SubdocProjectionDoc, { 'author.name': 1 }>['author']>().type.toBe<SubdocProjectionDoc['author']>();

Test.findOneAndUpdate({}, {}, { projection: { name: 1 } }).then(doc => {
  expect(doc!).type.toHaveProperty('name');
  expect(doc!).type.not.toHaveProperty('age');
  expect(doc!).type.toHaveProperty('_id');
});
Test.findOneAndDelete({}, { projection: { name: 1 } }).then(doc => {
  expect(doc!).type.toHaveProperty('name');
  expect(doc!).type.not.toHaveProperty('age');
  expect(doc!).type.toHaveProperty('_id');
});
Test.findOneAndReplace({}, {}, { projection: { name: 1 } }).then(doc => {
  expect(doc!).type.toHaveProperty('name');
  expect(doc!).type.not.toHaveProperty('age');
  expect(doc!).type.toHaveProperty('_id');
});
Test.findOneAndReplace({}, {}, { projection: { age: 0, _id: 1 }, includeResultMetadata: true }).then(res => {
  expect(res.value!).type.toHaveProperty('name');
  expect(res.value!).type.not.toHaveProperty('age');
  expect(res.value!).type.toHaveProperty('_id');
});
Test.findOneAndUpdate({}, {}, { projection: { age: 0, _id: 1 }, lean: true }).then(doc => {
  expect(doc!).type.toHaveProperty('name');
  expect(doc!).type.not.toHaveProperty('age');
  expect(doc!).type.toHaveProperty('_id');
});
Test.findOneAndDelete({}, { projection: { age: 0, _id: 1 }, lean: true }).then(doc => {
  expect(doc!).type.toHaveProperty('name');
  expect(doc!).type.not.toHaveProperty('age');
  expect(doc!).type.toHaveProperty('_id');
});
Test.findOneAndReplace({}, {}, { projection: { age: 0, _id: 1 }, lean: true }).then(doc => {
  expect(doc!).type.toHaveProperty('name');
  expect(doc!).type.not.toHaveProperty('age');
  expect(doc!).type.toHaveProperty('_id');
});
Test.findOneAndUpdate({}, {}, { projection: { name: 1 }, lean: true, includeResultMetadata: true }).then(res => {
  expect(res.value!).type.toHaveProperty('name');
  expect(res.value!).type.not.toHaveProperty('age');
  expect(res.value!).type.toHaveProperty('_id');
});
Test.findOneAndDelete({}, { projection: { name: 1 }, lean: true, includeResultMetadata: true }).then(res => {
  expect(res.value!).type.toHaveProperty('name');
  expect(res.value!).type.not.toHaveProperty('age');
  expect(res.value!).type.toHaveProperty('_id');
});
Test.findOneAndReplace({}, {}, { projection: { name: 1 }, lean: true, includeResultMetadata: true }).then(res => {
  expect(res.value!).type.toHaveProperty('name');
  expect(res.value!).type.not.toHaveProperty('age');
  expect(res.value!).type.toHaveProperty('_id');
});
Test.findByIdAndUpdate(new Types.ObjectId(), {}, { projection: { name: 1 }, lean: true }).then(doc => {
  expect(doc!).type.toHaveProperty('name');
  expect(doc!).type.not.toHaveProperty('age');
  expect(doc!).type.toHaveProperty('_id');
});
Test.findByIdAndUpdate(new Types.ObjectId(), {}, { projection: { name: 1 }, lean: true, includeResultMetadata: true }).then(res => {
  expect(res.value!).type.toHaveProperty('name');
  expect(res.value!).type.not.toHaveProperty('age');
  expect(res.value!).type.toHaveProperty('_id');
});
Test.findByIdAndDelete(new Types.ObjectId(), { projection: { name: 1 }, lean: true }).then(doc => {
  expect(doc!).type.toHaveProperty('name');
  expect(doc!).type.not.toHaveProperty('age');
  expect(doc!).type.toHaveProperty('_id');
});
Test.findByIdAndDelete(new Types.ObjectId(), { projection: { name: 1 }, lean: true, includeResultMetadata: true }).then(res => {
  expect(res.value!).type.toHaveProperty('name');
  expect(res.value!).type.not.toHaveProperty('age');
  expect(res.value!).type.toHaveProperty('_id');
});

Test.find({}, { 'docs.$': 1 }).then(docs => {
  expect(docs[0]).type.not.toHaveProperty('name');
  expect(docs[0]).type.toHaveProperty('docs');
  expect(docs[0]).type.toHaveProperty('_id');
});
Test.findOne({}, { docs: { $elemMatch: { id: 1 } } }).then(doc => {
  expect(doc!).type.not.toHaveProperty('name');
  expect(doc!).type.toHaveProperty('docs');
  expect(doc!).type.toHaveProperty('_id');
});
Test.findOneAndUpdate({}, {}, { projection: { tags: { $slice: 1 } } }).then(doc => {
  expect(doc!).type.toHaveProperty('name');
  expect(doc!).type.toHaveProperty('docs');
  expect(doc!).type.toHaveProperty('_id');
});
Test.findOneAndDelete({}, { projection: { name: { $meta: 'textScore' } } }).then(doc => {
  expect(doc!).type.toHaveProperty('name');
  expect(doc!).type.toHaveProperty('docs');
  expect(doc!).type.toHaveProperty('_id');
});

Test.find().byName('test').byName('test2').orFail().exec().then(console.log);

Test.countDocuments({ name: /Test/ }).exec().then((res: number) => console.log(res));
Test.findOne({ 'docs.id': 42 }).exec().then(console.log);

Test.findAndCount({ name: /Test/ }, null, { sort: { name: 1 }, limit: 10 }).then(([docs, count]) => {
  expect(docs[0].name).type.toBe<string | undefined>();
  expect<typeof count>().type.toBe<number>();
});
Test.findAndCount({ name: /Test/ }, null, { sort: { name: 1 }, limit: 10, lean: true }).then(([docs, count]) => {
  expect(docs[0].name).type.toBe<string | undefined>();
  expect<typeof count>().type.toBe<number>();
});

// ObjectId casting
Test.find({ parent: new Types.ObjectId('0'.repeat(24)) });
Test.find({ parent: '0'.repeat(24) });
Test.find({ parent: { $in: ['0'.repeat(24)] } });

// Operators
Test.find({ name: { $in: ['Test'] } }).exec().then((res: Array<ITest>) => console.log(res));
Test.find({ tags: 'test' }).exec();
Test.find({ tags: { $in: ['test'] } }).exec();
Test.find({ tags: /test/ }).exec();
Test.find({ tags: { $in: [/test/] } }).exec();

// Implicit `$in`
Test.find({ name: ['Test1', 'Test2'] }).exec();

// Implicit `$in` for regex string
Test.find({ name: [/Test1/, /Test2/] });

Test.find({ name: { $gte: 'Test' } }, null, { collation: { locale: 'en-us' } }).exec().
  then((res: Array<ITest>) => console.log(res[0].name));

Test.findOne().orFail(new Error('bar')).then((doc: ITest | null) => console.log('Found! ' + doc));

Test.distinct('name').exec().then((res: Array<any>) => console.log(res[0]));
Test.distinct('name', {}, { collation: { locale: 'en', strength: 2 } }).exec().then((res: Array<any>) => console.log(res[0]));

Test.findOneAndUpdate({ name: 'test' }, { name: 'test2' }).exec().then((res: ITest | null) => console.log(res));
Test.findOneAndUpdate({ name: 'test' }, { name: 'test2' }).then((res: ITest | null) => console.log(res));
Test.findOneAndUpdate({ name: 'test' }, { $set: { name: 'test2' } }).then((res: ITest | null) => console.log(res));
Test.findOneAndUpdate({ name: 'test' }, { $inc: { age: 2 } }).then((res: ITest | null) => console.log(res));
Test.findOneAndUpdate({ name: 'test' }, { name: 'test3' }, { upsert: true, new: true }).then((res: ITest) => {
  res.name = 'test4';
});
Test.findOneAndUpdate({ name: 'test' }, { name: 'test3' }, { upsert: true, returnOriginal: false }).then((res: ITest) => {
  res.name = 'test4';
});
Test.findOneAndUpdate({ name: 'test' }, { name: 'test3' }, { includeResultMetadata: true }).then((res: any) => {
  console.log(res.ok);
});
Test.findOneAndUpdate({ name: 'test' }, { name: 'test3' }, { new: true, upsert: true, includeResultMetadata: true }).then((res: any) => {
  console.log(res.ok);
});
Test.findOneAndUpdate({ name: 'test' }, { name: 'test3' }, { cloneUpdate: false });

Test.findOneAndReplace({ name: 'test' }, { _id: new Types.ObjectId(), name: 'test2' }).exec().then((res: ITest | null) => console.log(res));

Test.findOneAndUpdate({ name: 'test' }, { $addToSet: { tags: 'each' } });
Test.findOneAndUpdate({ name: 'test' }, { $push: { tags: 'each' } });
Test.findOneAndUpdate({ name: 'test' }, { $pull: { docs: { 'nested.id': 1 } } });

Test.findOneAndUpdate({ name: 'test', 'docs.id': 1 }, { $pull: { 'docs.$.tags': 'foo' } });

const update = Math.random() > 0.5 ? { $unset: { 'docs.0': 1 } } : { age: 55 };
Test.findOneAndUpdate({ name: 'test' }, update);

Test.findOneAndUpdate({ name: 'test' }, { $currentDate: { endDate: true } });
Test.findOneAndUpdate({ name: 'test' }, [{ $set: { endDate: true } }]);
Test.findOneAndUpdate().setUpdate({ $set: { name: 'test' } }, false);

Test.findByIdAndUpdate({ name: 'test' }, { name: 'test2' }, (err: any, doc: any) => console.log(doc));

Test.findOneAndUpdate({ name: 'test' }, { 'docs.0.myId': '0'.repeat(24) });

// Chaining
Test.findOne().where({ name: 'test' });
Test.where().find({ name: 'test' });

// Projection
const p0: Record<string, number> = Test.find().projection({
  age: true,
  parent: 1,
  'docs.id': 1
});
const p1: Record<string, number> = Test.find().projection('age docs.id');
const p2: Record<string, number> | null = Test.find().projection();
const p3: null = Test.find().projection(null);

expect(Test.find).type.not.toBeCallableWith({}, { name: 'ss' }); // Only 0 and 1 are allowed
Test.find({}, { name: 3 });
Test.find({}, { name: true, age: false, endDate: true, tags: 1 });
Test.find({}, { name: true, age: false, endDate: true });
Test.find({}, { name: false, age: false, tags: false, child: { name: false }, docs: { myId: false, id: true } });
expect(Test.find).type.not.toBeCallableWith({}, { tags: { something: 1 } }); // Array of strings or numbers should only be allowed to be a boolean or 1 and 0
Test.find({}, { name: true, age: true, endDate: true, tags: 1, child: { name: true }, docs: { myId: true, id: true } }); // This should be allowed
Test.find({}, { name: 1, age: 1, endDate: 1, tags: 1, child: { name: 1 }, docs: { myId: 1, id: 1 } }); // This should be allowed
Test.find({}, { _id: 0, name: 1, age: 1, endDate: 1, tags: 1, child: 1, docs: 1 }); // _id is an exception and should be allowed to be excluded
Test.find({}, { name: 0, age: 0, endDate: 0, tags: 0, child: 0, docs: 0 }); // This should be allowed
Test.find({}, { name: 0, age: 0, endDate: 0, tags: 0, child: { name: 0 }, docs: { myId: 0, id: 0 } }); // This should be allowed
Test.find({}, { name: 1, age: 1, _id: 0 }); // This should be allowed since _id is an exception
Test.find({}, { someOtherField: 1 }); // This should be allowed since it's not a field in the schema
expect(Test.find).type.not.toBeCallableWith({}, { name: { $slice: 1 } }); // $slice should only be allowed on arrays
Test.find({}, { tags: { $slice: 1 } }); // $slice should be allowed on arrays
Test.find({}, { tags: { $slice: [1, 2] } }); // $slice with the format of [ <number to skip>, <number to return> ] should also be allowed on arrays
expect(Test.find).type.not.toBeCallableWith({}, { age: { $elemMatch: {} } }); // $elemMatch should not be allowed on non arrays
Test.find({}, { docs: { $elemMatch: { id: 'aa' } } }); // $elemMatch should be allowed on arrays
expect(Test.find).type.not.toBeCallableWith({}, { tags: { $slice: 1, $elemMatch: {} } }); // $elemMatch and $slice should not be allowed together
Test.find({}, { age: 1, tags: { $slice: 5 } }); // $slice should be allowed in inclusion projection
Test.find({}, { age: 0, tags: { $slice: 5 } }); // $slice should be allowed in exclusion projection
Test.find({}, { age: 1, tags: { $elemMatch: {} } }); // $elemMatch should be allowed in inclusion projection
Test.find({}, { age: 0, tags: { $elemMatch: {} } }); // $elemMatch should be allowed in exclusion projection
Test.find({}, { 'docs.$': 1 }); // Positional $ projection should be allowed
Test.find({}, { docs: { $elemMatch: { id: 1 } } }); // $elemMatch projection should be allowed
Test.find({}, { tags: { $slice: [0, 1] } }); // $slice projection should be allowed
Test.find({}, { name: { $meta: 'textScore' } }); // $meta projection should be allowed
expect(Test.find).type.not.toBeCallableWith({}, { 'docs.id': 'taco' }); // Dot notation should be allowed and does not accept any
expect(Test.find).type.not.toBeCallableWith({}, { docs: { id: '1' } }); // Dot notation should be able to use a combination with objects
Test.find({}, { docs: { id: false } }); // Dot notation should be allowed with valid values - should correctly handle arrays
Test.find({}, { docs: { id: true } }); // Dot notation should be allowed with valid values - should correctly handle arrays
Test.find({ docs: { $elemMatch: { id: 1 } } }, { 'docs.$': 1 }); // $ projection should be allowed
Test.find({}, { child: 1 }); // Dot notation should be able to use a combination with objects
// Test.find({}, { 'docs.profiles': { name: 1 } }); // 3 levels deep not supported
expect(Test.find).type.not.toBeCallableWith({}, { 'docs.profiles': { name: 'aa' } }); // should support a combination of dot notation and objects
expect(Test.find).type.not.toBeCallableWith({}, { endDate: { toString: 1 } }); // should not allow projecting inherited methods in nested objects
expect(Test.find).type.not.toBeCallableWith({}, { tags: { trim: 1 } }); // should not allow projecting inherited methods in nested objects
expect(Test.find).type.not.toBeCallableWith({}, { child: { toJSON: 1 } }); // should not allow projecting inherited methods in nested objects
Test.find({}, { age: 1, _id: 0 });
Test.find({}, { name: 0, age: 0, _id: 1 });

// Manual Casting using ProjectionType
Test.find({}, { docs: { unknownParams: 1 } } as ProjectionType<ITest>);
// Sorting
Test.find().sort();
Test.find().sort('-name');
Test.find().sort({ name: -1 });
Test.find().sort({ name: 'ascending' });
Test.find().sort(undefined);
Test.find().sort(null);
Test.find().sort([['key', 'ascending']]);
Test.find().sort([['key1', 'ascending'], ['key2', 'descending']]);
expect(Test.find().sort).type.not.toBeCallableWith({ name: 2 });
expect(Test.find().sort).type.not.toBeCallableWith({ name: 'invalidSortOrder' });
expect(Test.find().sort).type.not.toBeCallableWith([['key', 'invalid']]);
expect(Test.find().sort).type.not.toBeCallableWith([['key', false]]);
expect(Test.find().sort).type.not.toBeCallableWith(['invalid']);

// Super generic query
function testGenericQuery(): void {
  interface CommonInterface<T> {
    something: string;
    content: T;
  }

  async function findSomething<T>(model: Model<CommonInterface<T>>): Promise<CommonInterface<T>> {
    return model.findOne({ something: 'test' } as mongoose.QueryFilter<CommonInterface<T>>).orFail().exec();
  }
}

function eachAsync(): void {
  Test.find().cursor().eachAsync((doc) => {
    expect(doc).type.toBe<HydratedDocument<ITest, {}, QueryHelpers>>();
  });
  Test.find().cursor().eachAsync((docs) => {
    expect(docs).type.toBe<HydratedDocument<ITest, {}, QueryHelpers>[]>();
  }, { batchSize: 2 });
}

async function gh10617(): Promise<void> {
  interface IDBModel extends Document {
    date: Date; // date created
    _tags: any[];
  }

  const schema = new Schema({
    date: { type: Date, default: Date.now }, // date created
    _tags: [{ type: Schema.Types.ObjectId, ref: 'Tag' }]
  });

  const DBModel: Model<IDBModel> = model<IDBModel>('Meep', schema);
  await DBModel.findOne({});
}

function gh10757() {
  enum MyEnum {
    VALUE1,
    VALUE2,
    VALUE3
  }

  interface MyClass {
    status: MyEnum;
  }

  type MyClassDocument = MyClass & Document;

  const test: QueryFilter<MyClass> = { status: { $in: [MyEnum.VALUE1, MyEnum.VALUE2] } };
}

function gh10857() {
  type MyUnion = 'VALUE1' | 'VALUE2';
  interface MyClass {
    status: MyUnion;
  }
  type MyClassDocument = MyClass & Document;
  const test: QueryFilter<MyClass> = { status: { $in: ['VALUE1', 'VALUE2'] } };
  expect<QueryFilter<MyClass>>().type.not.toBeAssignableFrom({ status: 'nope' });
}

function gh16240() {
  enum Status {
    ACTIVE = 'active',
    BANNED = 'banned'
  }

  interface MyClass {
    statusUnion: 'active' | 'banned';
    statusEnum: Status;
    name: string;
  }

  expect<QueryFilter<MyClass>>().type.not.toBeAssignableFrom({
    statusUnion: 'nope'
  });
  expect<QueryFilter<MyClass>>().type.not.toBeAssignableFrom({
    statusEnum: 'nope'
  });
  expect<QueryFilter<MyClass>>().type.toBeAssignableFrom({
    statusUnion: 'active'
  } as const);
  expect<QueryFilter<MyClass>>().type.toBeAssignableFrom({
    statusEnum: Status.ACTIVE
  });
  expect<QueryFilter<MyClass>>().type.toBeAssignableFrom({
    name: /valid/
  } as const);
}

function gh10786() {
  interface User {
    phone?: string;
    name?: string
  }

  const updateQuery: UpdateQuery<User> = { name: 'John' };
  if (true) {
    updateQuery.phone = 'XXXX';
  }
}

async function gh11156(): Promise<void> {
  interface IUser {
    name: string;
    age: number;
  }

  const schema = new Schema<IUser>({
    name: String,
    age: Number
  });

  const User: Model<IUser> = model<IUser>('User', schema);

  const doc = await User.findOne<Pick<IUser, 'name'>>({}).orFail();
  expect(doc).type.toBe<{ name: string }>();
}

async function gh11041(): Promise<void> {
  interface User {
    name: string;
    email: string;
    avatar?: string;
  }

  // 2. Create a Schema corresponding to the document interface.
  const schema = new Schema<User>({
    name: { type: String, required: true },
    email: { type: String, required: true },
    avatar: String
  });

  // 3. Create a Model.
  const MyModel = model<User>('User', schema);

  expect(await MyModel.findOne({}).populate('someField').exec()).type.toBe<HydratedDocument<User> | null>();
}

async function gh11306(): Promise<void> {
  interface User {
    name: string;
    email: string;
    avatar?: string;
  }

  // 2. Create a Schema corresponding to the document interface.
  const schema = new Schema<User>({
    name: { type: String, required: true },
    email: { type: String, required: true },
    avatar: String
  });

  // 3. Create a Model.
  const MyModel = model<User>('User', schema);

  expect(await MyModel.distinct('notThereInSchema')).type.toBe<unknown[]>();
  expect(await MyModel.distinct('name')).type.toBe<string[]>();
}

function autoTypedQuery() {
  const AutoTypedModel = autoTypedModel();
  const query = AutoTypedModel.find();
  expect(AutoTypedModel.find().byUserName('')).type.toBe<typeof query>();
}

function gh11964() {
  class Repository<T extends { id: string }> {
    find(id: string) {
      const idCondition: Condition<T['id']> = id as Condition<T['id']>;

      // `as` is necessary because `T` can be `{ id: never }`,
      // so we need to explicitly coerce
      const filter: QueryFilter<T> = { id } as QueryFilter<T>;
    }
  }
}

function gh14397() {
  type WithId<T extends object> = T & { id: string };

  type TestUser = {
    name: string;
    age: number;
  };

  const id = 'Test Id';

  expect<Condition<WithId<TestUser>['id']>>().type.toBeAssignableFrom(id);
  expect<QueryFilter<WithId<TestUser>>>().type.toBeAssignableFrom({ id });
}

function gh12091() {
  interface IUser{
    friendsNames: string[];
  }
  const userSchema = new Schema<IUser>({
    friendsNames: [String]
  });

  const update: UpdateQuery<IUser> = { $addToSet: { friendsNames: 'John Doe' } };
  if (!update?.$addToSet) {
    return;
  }
  update.$addToSet.friendsNames = 'Jane Doe';
}

function gh12142() {
  const schema = new Schema({ name: String, comments: [{ text: String }] });

  const Test = model('Test', schema);

  Test.updateOne(
    { _id: new Types.ObjectId() },
    {
      $pull: { comments: new Types.ObjectId() }
    },
    { cloneUpdate: false }
  );
}

async function gh12342_manual() {
  interface Project {
    name?: string, stars?: number
  }

  interface ProjectQueryHelpers {
    byName(name: string): QueryWithHelpers<
    HydratedDocument<Project>[],
    HydratedDocument<Project>,
    ProjectQueryHelpers
    >
  }

  type ProjectModelType = Model<Project, ProjectQueryHelpers>;

  const ProjectSchema = new Schema<
  Project,
  Model<Project, ProjectQueryHelpers>,
  {},
  ProjectQueryHelpers
  >({
    name: String,
    stars: Number
  });

  ProjectSchema.query.byName = function byName(
    this: QueryWithHelpers<any, HydratedDocument<Project>, ProjectQueryHelpers>,
    name: string
  ) {
    return this.find({ name: name });
  };

  // 2nd param to `model()` is the Model class to return.
  const ProjectModel = model<Project, ProjectModelType>('Project', schema);

  expect(await ProjectModel.findOne().where('stars').gt(1000).byName('mongoose')).type.toBe<HydratedDocument<Project>[]>();

}

async function gh12342_auto() {
  interface Project {
    name?: string | null,
    stars?: number | null
  }

  const ProjectSchema = new Schema({
    name: String,
    stars: Number
  }, {
    query: {
      byName(name: string) {
        return this.find({ name });
      }
    }
  });

  const ProjectModel = model('Project', ProjectSchema);

  expect(await ProjectModel.findOne().where('stars').gt(1000).byName('mongoose')).type.toBe<HydratedDocument<Project>[]>();
}

async function gh11602(): Promise<void> {
  const query = Test.findOne();
  query instanceof Query;

  const ModelType = model<ITest>('foo', schema);

  const updateResult = await ModelType.findOneAndUpdate(query, { $inc: { occurence: 1 } }, {
    upsert: true,
    returnDocument: 'after',
    includeResultMetadata: true
  });

  expect(updateResult.lastErrorObject!).type.not.toHaveProperty('modifiedCount');
  expect(updateResult.lastErrorObject?.updatedExisting).type.toBe<boolean | undefined>();
  expect(updateResult.lastErrorObject?.upserted).type.toBe<ObjectId | undefined>();

  ModelType.findOneAndUpdate({}, {}, { returnDocument: 'before' });
  ModelType.findOneAndUpdate({}, {}, { returnDocument: 'after' });
  ModelType.findOneAndUpdate({}, {}, {});
  expect(ModelType.findOneAndUpdate).type.not.toBeCallableWith({}, {}, { returnDocument: 'not-before-or-after' }); // returnDocument should be 'before' or 'after'
}

async function gh13142() {
  const BlogSchema = new Schema({ title: String });

  type Blog = InferSchemaType<typeof BlogSchema>;

  const BlogModel = model<Blog>('Blog', BlogSchema);
  class BlogRepository {
    private readonly blogModel: Model<Blog>;

    constructor() {
      this.blogModel = BlogModel;
    }

    findOne<
      Projection extends ProjectionFields<Blog>,
      Options extends QueryOptions<Blog>
    >(
      filter: QueryFilter<mongoose.WithLevel1NestedPaths<Blog>>,
      projection: Projection,
      options: Options
    ): Promise<
        Options['lean'] extends true
          ? Pick<Blog, Extract<keyof Projection, keyof Blog>> | null
          : HydratedDocument<Pick<Blog, Extract<keyof Projection, keyof Blog>>> | null
    > {
      return this.blogModel.findOne(filter, projection, options);
    }
  }

  const blogRepository = new BlogRepository();
  const blog = await blogRepository.findOne(
    { title: 'test' },
    { content: 1 },
    { lean: true }
  );
  if (!blog) return;
  expect(blog).type.toBe<Pick<Blog, Extract<keyof { content: 1 }, keyof Blog>>>();
}

async function gh13224() {
  const userSchema = new Schema({ name: String, age: Number });
  const UserModel = model('User', userSchema);

  const u1 = await UserModel.findOne().select(['name']).orFail();
  expect(u1.name).type.toBe<string | undefined | null>();
  expect(u1.age).type.toBe<number | undefined | null>();
  expect(u1.toObject).type.toBeAssignableTo<Function>();

  const u2 = await UserModel.findOne().select<{ name?: string }>(['name']).orFail();
  expect(u2.name).type.toBe<string | undefined>();
  expect(u2).type.not.toHaveProperty('age');
  expect(u2.toObject).type.toBeAssignableTo<Function>();

  const users = await UserModel.find().select<{ name?: string }>(['name']);
  const u3 = users[0];
  expect(u3.name).type.toBe<string | undefined>();
  expect(u3).type.not.toHaveProperty('age');
  expect(u3.toObject).type.toBeAssignableTo<Function>();

  expect(UserModel.findOne().select).type.not.toBeInstantiableWith<[{ notInSchema: string }]>();
}

function gh13630() {
  interface User {
    phone?: string;
    name?: string;
    nested?: {
      test?: string;
    }
  }

  expect<UpdateQueryKnownOnly<User>>().type.toBeAssignableFrom({ $set: { name: 'John' } });
  expect<UpdateQueryKnownOnly<User>>().type.toBeAssignableFrom({ $unset: { phone: 'test' } });
  expect<UpdateQueryKnownOnly<User>>().type.toBeAssignableFrom({ $set: { nested: { test: 'foo' } } });
  expect<UpdateQueryKnownOnly<User>>().type.not.toBeAssignableFrom({ $set: { namee: 'foo' } });
  expect<UpdateQueryKnownOnly<User>>().type.not.toBeAssignableFrom({ $set: { 'nested.test': 'foo' } });

  expect<UpdateQueryKnownOnly<User>>().type.toBeAssignableTo<UpdateQuery<User>>();
}

async function gh14190() {
  const userSchema = new Schema({ name: String, age: Number });
  const UserModel = model('User', userSchema);

  const doc = await UserModel.findByIdAndDelete('0'.repeat(24));
  expect(doc).type.toBe<ReturnType<(typeof UserModel)['hydrate']> | null>();

  const res = await UserModel.findByIdAndDelete(
    '0'.repeat(24),
    { includeResultMetadata: true }
  );
  expect(res).type.toBeAssignableTo<
    ModifyResult<ReturnType<(typeof UserModel)['hydrate']>>
  >();

  const res2 = await UserModel.find().findByIdAndDelete(
    '0'.repeat(24),
    { includeResultMetadata: true }
  );
  expect(res2).type.toBeAssignableTo<
    ModifyResult<ReturnType<(typeof UserModel)['hydrate']>>
  >();
}

function mongooseQueryOptions() {
  const userSchema = new Schema({ name: String, age: Number });
  const UserModel = model('User', userSchema);

  UserModel.updateOne(
    { name: 'bar' },
    { name: 'baz' },
    {
      context: 'query',
      multipleCastError: true,
      overwriteDiscriminatorKey: true,
      runValidators: true,
      sanitizeProjection: true,
      sanitizeFilter: true,
      setDefaultsOnInsert: true,
      strict: true,
      strictQuery: 'throw',
      timestamps: false,
      translateAliases: false
    }
  );

  UserModel.findOne({}, null, {
    lean: true,
    populate: 'test'
  });
}

function gh14473() {
  class AbstractSchema {
    _id: any;
    createdAt: Date;
    updatedAt: Date;
    deletedAt: Date;

    constructor() {
      this._id = 4;
      this.createdAt = new Date();
      this.updatedAt = new Date();
      this.deletedAt = new Date();
    }
  }

  const generateExists = <D extends AbstractSchema = AbstractSchema>() => {
    const query: QueryFilter<D> = { deletedAt: { $ne: null } };
    const query2: QueryFilter<D> = { deletedAt: { $lt: new Date() } } as QueryFilter<D>;
  };
}

async function gh14525() {
  type BeAnObject = Record<string, any>;

  interface SomeDoc {
    something: string;
    func(this: TestDoc): string;
  }

  interface PluginExtras {
    pfunc(): number;
  }

  type TestDoc = Document<unknown, BeAnObject, SomeDoc> & PluginExtras;

  type ModelType = Model<SomeDoc, BeAnObject, PluginExtras, BeAnObject>;

  const doc = await ({} as ModelType).findOne({}).populate('test').orFail().exec();

  doc.func();

  let doc2 = await ({} as ModelType).create({});
  doc2 = await ({} as ModelType).findOne({}).populate('test').orFail().exec();
}

async function gh14545() {
  type Test = {
    _id: Types.ObjectId;

    prop: string;
    another: string;

    createdAt: number;
    updatedAt: number;
  };

  const schema = new Schema<Test>({
    prop: { type: String },
    another: { type: String },
    createdAt: { type: Number },
    updatedAt: { type: Number }
  });

  type TestDocument = HydratedDocument<Test>;
  type TestModel = Model<Test, {}, {}, {}, TestDocument>;

  type SlimTest = Pick<Test, '_id' | 'prop'>;
  type SlimTestDocument = HydratedDocument<SlimTest>;

  const M = model<Test, TestModel>('Test', schema);

  const myDocs = await M.find({}).exec();
  const myDoc = await M.findOne({}).exec();

  expect(await M.find({}).select<SlimTest>({ prop: 1 }).exec()).type.toBe<SlimTestDocument[]>();
  expect(await M.findOne({}).select<SlimTest>({ prop: 1 }).exec()).type.toBe<SlimTestDocument | null>();
}

function gh14841() {
  const filter: QueryFilter<{ owners: string[] }> = {
    $expr: { $lt: [{ $size: '$owners' }, 10] }
  };
}

function gh14510() {
  // From https://stackoverflow.com/questions/56505560/how-to-fix-ts2322-could-be-instantiated-with-a-different-subtype-of-constraint:
  // "Never assign a concrete type to a generic type parameter, consider it as read-only!"
  // This function is generally something you shouldn't do in TypeScript, can work around it with `as` though.
  function findById<ModelType extends {_id: Types.ObjectId | string}>(model: Model<ModelType>, _id: Types.ObjectId | string) {
    return model.find({ _id: _id } as QueryFilter<ModelType>);
  }
}

async function gh15526() {
  const userSchemaDefinition = { name: String, age: Number } as const;
  const UserModel = model('User', new Schema(userSchemaDefinition));
  type UserType = InferRawDocType<typeof userSchemaDefinition>;

  const selection = ['name'] as const satisfies readonly (keyof UserType)[];

  type SelectType = Pick<UserType, (typeof selection)[number]>;
  const u1 = await UserModel.findOne()
    .select<SelectType>(selection)
    .orFail();
  expect(u1.name).type.toBe<string | undefined | null>();
  expect(u1).type.not.toHaveProperty('age');
}

async function gh14173() {
  const userSchema = new Schema({
    name: String,
    account: {
      amount: Number,
      owner: { type: String, default: () => 'OWNER' },
      taxIds: [Number]
    }
  });
  const User = model('User', userSchema);

  const { _id } = await User.create({
    name: 'test',
    account: {
      amount: 25,
      owner: 'test',
      taxIds: [42]
    }
  });

  const doc = await User
    .findOne({ _id }, { name: 1, account: { amount: 1 } })
    .orFail();
}

async function gh3230() {
  const Test = model(
    'Test',
    new Schema({ name: String, arr: [{ testRef: { type: 'ObjectId', ref: 'Test2' } }] })
  );

  const schema = new Schema({ name: String });
  const Test2 = model('Test2', schema);
  const D = Test2.discriminator('D', new Schema({ prop: String }));


  await Test.deleteMany({});
  await Test2.deleteMany({});
  const { _id } = await D.create({ name: 'foo', prop: 'bar' });
  const test = await Test.create({ name: 'test', arr: [{ testRef: _id }] });

  console.log(await Test.findById(test._id).populate('arr.testRef', { name: 1, prop: 1, _id: 0, __t: 0 }));
}

async function gh12064() {
  const schema = new Schema({
    subdoc: new Schema({
      subdocProp: Number
    }),
    nested: {
      nestedProp: String
    },
    documentArray: [{ documentArrayProp: Boolean }]
  });
  const TestModel = model('Model', schema);

  await TestModel.findOne({ 'subdoc.subdocProp': { $gt: 0 }, 'nested.nestedProp': { $in: ['foo', 'bar'] }, 'documentArray.documentArrayProp': { $ne: true } });
  expect(TestModel.findOne).type.not.toBeCallableWith({ 'subdoc.subdocProp': 'taco tuesday' });
  expect(TestModel.findOne).type.not.toBeCallableWith({ 'nested.nestedProp': true });
  expect(TestModel.findOne).type.not.toBeCallableWith({ 'documentArray.documentArrayProp': 'taco' });
}

function gh15671() {
  interface DefaultQuery {
    search?: string;
  }

  type QueryFeaturesProps = {
    params: Partial<DefaultQuery>;
  };

  const queryFeatures = async <T, R, TQueryOp>(
    query: mongoose.Query<R, T, object, T, TQueryOp>,
    { params }: QueryFeaturesProps
  ): Promise<{ content: mongoose.GetLeanResultType<T, R, TQueryOp>; result?: number }> => {
    if (params.search) {
      query.find({
        $text: {
          $search: params.search
        }
      });
    }

    const content = await query.lean().orFail().exec();
    return {
      content
    };
  };
}

async function gh15779() {
  type Entity = {
    id: string;
    age: number;
    name: string;
  };

  function getV8FilterQuery(filter: QueryFilter<Entity>): QueryFilter<Entity> {
    return { ...filter, deletedAt: null };
  }

  const v8Filter = getV8FilterQuery({ age: { $gt: 18 } });

  v8Filter.name = 'test';

  expect(v8Filter.age).type.toBeAssignableFrom(42);
  expect(v8Filter.age).type.not.toBeAssignableFrom('taco');

  const TestModel = model('Test', new Schema({ age: Number, name: String }));
  const query = TestModel.find({ age: { $gt: 18 } });
  TestModel.find(query); // Should compile without errors
  TestModel.findOne(query);
  TestModel.deleteMany(query);
}

async function gh15786() {
  interface IDoc {
    nmae: string;
  }

  interface DocStatics {
    m1(): void;
    m2(): void;
  }

  const schema = new Schema<IDoc, Model<IDoc>, {}, {}, {}, DocStatics>({});
  schema.static({ m1() {} });
}

async function gh15779_2() {
  interface Job {
    _id: Types.ObjectId;
    name: string;
  }

  const jobSchema = new Schema<Job>({ name: String });
  const JobModel = model<Job>('Job', jobSchema);

  const jobs = await JobModel.aggregate<Job>([
    { $match: {} as QueryFilter<Job> }
  ]);
}

async function gh16062() {
  const Test = model('Test', new Schema({ runtime: Number }));
  expect(Test.findOne).type.not.toBeCallableWith({ runtime: { $wrong: 100 } });
  expect(Test.findOne).type.not.toBeCallableWith({ $and: [{ runtime: { $wrong: 100 } }] });
}

async function defaultSortFindAndCount() {
  const Sorted = model('DefaultSort', new Schema({ name: String }, { defaultSort: { name: 1 } }));
  const [docs, total] = await Sorted.findAndCount({}, null, { limit: 10 });
  expect(docs[0].name).type.toBe<string | null | undefined>();
  expect(total).type.toBe<number>();
  await Sorted.findAndCount({}, null, { sort: { _id: 1 }, limit: 10 });
  await Sorted.find().sort(null);
  await Sorted.find().sort({});

  const StringSorted = model('DefaultSort2', new Schema({ name: String }, { defaultSort: '-name _id' }));
  await StringSorted.findAndCount({}, null, { limit: 10 });

  const Unsorted = model('NoDefaultSort', new Schema({ name: String }));
  // @ts-expect-error  Property 'sort' is missing
  await Unsorted.findAndCount({}, null, { limit: 10 });

  const Disabled = model('DisabledDefaultSort', new Schema({ name: String }, { defaultSort: false }));
  // @ts-expect-error  Property 'sort' is missing
  await Disabled.findAndCount({}, null, { limit: 10 });

  const MaybeSorted = model('MaybeDefaultSort', new Schema({ name: String }, { defaultSort: Math.random() > 0.5 ? { name: 1 } : undefined }));
  // @ts-expect-error  Property 'sort' is missing
  await MaybeSorted.findAndCount({}, null, { limit: 10 });

  const SortedEitherWay = model('EitherDefaultSort', new Schema({ name: String }, { defaultSort: Math.random() > 0.5 ? { name: 1 } : '-name' }));
  await SortedEitherWay.findAndCount({}, null, { limit: 10 });

  // @ts-expect-error  Property 'limit' is missing
  await Sorted.findAndCount({}, null, {});

  // @ts-expect-error  Type '2' is not assignable to type
  new Schema({ name: String }, { defaultSort: { name: 2 } });

  // @ts-expect-error  Type '{ $meta: string; }' is not assignable to type
  new Schema({ name: String }, { defaultSort: { score: { $meta: 'textScore' } } });
}

async function nestedProjectionOnDocumentArrayWithMethods() {
  type Item = { a: string; b: number };
  type ItemDoc = Types.Subdocument<Types.ObjectId, unknown, Item> & Item & { itemMethod(): string };
  type Parent = { _id: string; items: Types.DocumentArray<Item, ItemDoc> };

  const included: mongoose.ApplyProjection<Parent, { 'items.a': 1 }> = {} as any;
  expect(included.items[0]).type.toHaveProperty('a');
  expect(included.items[0]).type.not.toHaveProperty('b');
  expect(included.items[0]).type.toHaveProperty('itemMethod');
  expect(included.items.id('0')!).type.toHaveProperty('itemMethod');

  const excluded: mongoose.ApplyProjection<Parent, { 'items.a': 0 }> = {} as any;
  expect(excluded.items[0]).type.not.toHaveProperty('a');
  expect(excluded.items[0]).type.toHaveProperty('b');
  expect(excluded.items[0]).type.toHaveProperty('itemMethod');

  const meta: mongoose.ApplyProjection<Parent, { 'items.a': 1, 'items.score': { $meta: 'textScore' } }> = {} as any;
  expect(meta.items[0].score).type.toBe<number | undefined>();
  expect(meta.items[0]).type.toHaveProperty('a');
  expect(meta.items[0]).type.not.toHaveProperty('b');
  expect(meta.items[0]).type.toHaveProperty('itemMethod');
}

async function threeLevelNestedProjection() {
  const NestedPathModel = model('ThreeLevelNested', new Schema({
    a: { b: { c: String, d: Number }, e: String }
  }));
  const included = await NestedPathModel.findOne({}, { 'a.b.c': 1 }).orFail();
  expect(included.a!.b!).type.toHaveProperty('c');
  expect(included.a!.b!).type.not.toHaveProperty('d');
  expect(included.a!).type.not.toHaveProperty('e');

  const excluded = await NestedPathModel.findOne({}, { 'a.b.c': 0 }).orFail();
  expect(excluded.a!.b!).type.not.toHaveProperty('c');
  expect(excluded.a!.b!).type.toHaveProperty('d');
  expect(excluded.a!).type.toHaveProperty('e');

  const SubdocModel = model('ThreeLevelSubdoc', new Schema({
    a: new Schema({ b: new Schema({ c: String, d: Number }), e: String })
  }));
  const includedSubdoc = await SubdocModel.findOne({}, { 'a.b.c': 1 }).orFail();
  expect(includedSubdoc.a!.b!).type.toHaveProperty('c');
  expect(includedSubdoc.a!.b!).type.not.toHaveProperty('d');
  expect(includedSubdoc.a!).type.not.toHaveProperty('e');

  const DocumentArrayModel = model('ThreeLevelDocumentArray', new Schema({
    a: [{ b: [{ c: String, d: Number }], e: String }]
  }));
  const includedArr = await DocumentArrayModel.findOne({}, { 'a.b.c': 1 }).orFail();
  expect(includedArr.a[0].b[0]).type.toHaveProperty('c');
  expect(includedArr.a[0].b[0]).type.not.toHaveProperty('d');
  expect(includedArr.a[0].b[0]).type.toHaveProperty('ownerDocument');
  expect(includedArr.a[0]).type.not.toHaveProperty('e');
  expect(includedArr.a[0]).type.toHaveProperty('ownerDocument');

  const excludedArr = await DocumentArrayModel.findOne({}, { 'a.b.c': 0 }).orFail();
  expect(excludedArr.a[0].b[0]).type.not.toHaveProperty('c');
  expect(excludedArr.a[0].b[0]).type.toHaveProperty('d');
  expect(excludedArr.a[0]).type.toHaveProperty('e');
}

async function nestedProjectionOnArraysAndSubdocs() {
  const NestedProjectionModel = model('NestedProjection', new Schema({
    arr: [{ a: String, b: Number }],
    sub: new Schema({ a: String, b: Number })
  }));

  const projectedArr = await NestedProjectionModel.findOne({}, { 'arr.a': 1 }).orFail();
  expect(projectedArr.arr[0]).type.toHaveProperty('a');
  expect(projectedArr.arr[0]).type.toHaveProperty('ownerDocument');

  const projectedSub = await NestedProjectionModel.findOne({}, { 'sub.a': 1 }).orFail();
  expect(projectedSub.sub!).type.toHaveProperty('a');

  expect(projectedArr.arr[0]).type.not.toHaveProperty('b');
  expect(projectedArr.arr.addToSet).type.toBeCallableWith({ a: 'test' });

  const leanArr = await NestedProjectionModel.findOne({}, { 'arr.a': 1 }).orFail().lean();
  expect(leanArr.arr[0]).type.toHaveProperty('a');
  expect(leanArr.arr[0]).type.not.toHaveProperty('b');

  const excludedArr = await NestedProjectionModel.findOne({}, { 'arr.b': 0 }).orFail();
  expect(excludedArr.arr[0]).type.toHaveProperty('a');
  expect(excludedArr.arr[0]).type.not.toHaveProperty('b');
  expect(excludedArr.arr[0]).type.toHaveProperty('ownerDocument');

  const noMatchArr = await NestedProjectionModel.findOne({}, { 'arr.typo': 1 }).orFail();
  expect(noMatchArr.arr[0]).type.not.toHaveProperty('a');
  expect(noMatchArr.arr[0].save).type.not.toBe<never>();

  const dynamicPath = 'sub.a' as string;
  const excludedDynamicPath = await NestedProjectionModel.findOne({}, { [dynamicPath]: 0 as const }).orFail();
  expect(excludedDynamicPath).type.toHaveProperty('arr');
  expect(excludedDynamicPath).type.toHaveProperty('sub');
}
